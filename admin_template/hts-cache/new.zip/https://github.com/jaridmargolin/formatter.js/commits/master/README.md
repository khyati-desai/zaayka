





<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
  <link rel="dns-prefetch" href="https://assets-cdn.github.com">
  <link rel="dns-prefetch" href="https://avatars0.githubusercontent.com">
  <link rel="dns-prefetch" href="https://avatars1.githubusercontent.com">
  <link rel="dns-prefetch" href="https://avatars2.githubusercontent.com">
  <link rel="dns-prefetch" href="https://avatars3.githubusercontent.com">
  <link rel="dns-prefetch" href="https://github-cloud.s3.amazonaws.com">
  <link rel="dns-prefetch" href="https://user-images.githubusercontent.com/">



  <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://assets-cdn.github.com/assets/frameworks-8f281eb0a8d2308ceb36e714ba3c3aec.css" />
  <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://assets-cdn.github.com/assets/github-cec46cb7e4a6c4b4c35e2dac77b2196d.css" />
  
  
  <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://assets-cdn.github.com/assets/site-83dc1f7ebc9c7461fe1eab799b56c4c4.css" />
  

  <meta name="viewport" content="width=device-width">
  
  <title>History for README.md - jaridmargolin/formatter.js · GitHub</title>
    <meta name="description" content="GitHub is where people build software. More than 27 million people use GitHub to discover, fork, and contribute to over 80 million projects.">
  <link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="GitHub">
  <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
  <meta property="fb:app_id" content="1401488693436528">

    
    <meta property="og:image" content="https://avatars1.githubusercontent.com/u/933685?s=400&amp;v=4" /><meta property="og:site_name" content="GitHub" /><meta property="og:type" content="object" /><meta property="og:title" content="jaridmargolin/formatter.js" /><meta property="og:url" content="https://github.com/jaridmargolin/formatter.js" /><meta property="og:description" content="Format html inputs to match a specified pattern. Contribute to formatter.js development by creating an account on GitHub." />

  <link rel="assets" href="https://assets-cdn.github.com/">
  
  <meta name="pjax-timeout" content="1000">
  
  <meta name="request-id" content="7288:10FD:26CFF83:4682F63:5ACB646D" data-pjax-transient>


  

  <meta name="selected-link" value="repo_source" data-pjax-transient>

    <meta name="google-site-verification" content="KT5gs8h0wvaagLKAVWq8bbeNwnZZK1r1XQysX3xurLU">
  <meta name="google-site-verification" content="ZzhVyEFwb7w3e0-uOTltm8Jsck2F5StVihD0exw2fsA">
  <meta name="google-site-verification" content="GXs5KoUUkNCoaAZn7wPN-t01Pywp9M3sEjnt_3_ZWPc">
    <meta name="google-analytics" content="UA-3769691-2">

<meta name="octolytics-host" content="collector.githubapp.com" /><meta name="octolytics-app-id" content="github" /><meta name="octolytics-event-url" content="https://collector.githubapp.com/github-external/browser_event" /><meta name="octolytics-dimension-request_id" content="7288:10FD:26CFF83:4682F63:5ACB646D" /><meta name="octolytics-dimension-region_edge" content="iad" /><meta name="octolytics-dimension-region_render" content="iad" />
<meta name="hydro-events-url" content="https://github.com/hydro_browser_events" />
<meta name="analytics-location" content="/&lt;user-name&gt;/&lt;repo-name&gt;/commits/show" data-pjax-transient="true" />




  <meta class="js-ga-set" name="dimension1" content="Logged Out">


  

      <meta name="hostname" content="github.com">
    <meta name="user-login" content="">

      <meta name="expected-hostname" content="github.com">
    <meta name="js-proxy-site-detection-payload" content="YmY5Yjk2MWM3ZmYyODlmMTQzMjMwMzIxOTBhMmZkODE4YjllM2VjY2YzMDgxODEyZDJhNDM5NTljNTg1ODZjNHx7InJlbW90ZV9hZGRyZXNzIjoiMTE2LjcyLjUyLjIzMiIsInJlcXVlc3RfaWQiOiI3Mjg4OjEwRkQ6MjZDRkY4Mzo0NjgyRjYzOjVBQ0I2NDZEIiwidGltZXN0YW1wIjoxNTIzMjc4OTU4LCJob3N0IjoiZ2l0aHViLmNvbSJ9">

    <meta name="enabled-features" content="UNIVERSE_BANNER,FREE_TRIALS,MARKETPLACE_INSIGHTS,MARKETPLACE_SELF_SERVE,MARKETPLACE_INSIGHTS_CONVERSION_PERCENTAGES">

  <meta name="html-safe-nonce" content="c93ed10e39cc785bf529e2db8313369c9d932977">

  <meta http-equiv="x-pjax-version" content="4c09b81681961f2efccc0240274e1d51">
  

      <link href="https://github.com/jaridmargolin/formatter.js/commits/master.atom" rel="alternate" title="Recent Commits to formatter.js:master" type="application/atom+xml">

  <meta name="description" content="Format html inputs to match a specified pattern. Contribute to formatter.js development by creating an account on GitHub.">
  <meta name="go-import" content="github.com/jaridmargolin/formatter.js git https://github.com/jaridmargolin/formatter.js.git">

  <meta name="octolytics-dimension-user_id" content="933685" /><meta name="octolytics-dimension-user_login" content="jaridmargolin" /><meta name="octolytics-dimension-repository_id" content="12876724" /><meta name="octolytics-dimension-repository_nwo" content="jaridmargolin/formatter.js" /><meta name="octolytics-dimension-repository_public" content="true" /><meta name="octolytics-dimension-repository_is_fork" content="false" /><meta name="octolytics-dimension-repository_network_root_id" content="12876724" /><meta name="octolytics-dimension-repository_network_root_nwo" content="jaridmargolin/formatter.js" /><meta name="octolytics-dimension-repository_explore_github_marketplace_ci_cta_shown" content="false" />




  <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">

  <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">

  <link rel="mask-icon" href="https://assets-cdn.github.com/pinned-octocat.svg" color="#000000">
  <link rel="icon" type="image/x-icon" class="js-site-favicon" href="https://assets-cdn.github.com/favicon.ico">

<meta name="theme-color" content="#1e2327">



<link rel="manifest" href="/manifest.json" crossOrigin="use-credentials">

  </head>

  <body class="logged-out env-production">
    

  <div class="position-relative js-header-wrapper ">
    <a href="#start-of-content" tabindex="1" class="px-2 py-4bg-blue text-white show-on-focus js-skip-to-content">Skip to content</a>
    <div id="js-pjax-loader-bar" class="pjax-loader-bar"><div class="progress"></div></div>

    
    
    



        <header class="Header header-logged-out  position-relative f4 py-3" role="banner">
  <div class="container-lg d-flex px-3">
    <div class="d-flex flex-justify-between flex-items-center">
      <a class="header-logo-invertocat my-0" href="https://github.com/" aria-label="Homepage" data-ga-click="(Logged out) Header, go to homepage, icon:logo-wordmark">
        <svg height="32" class="octicon octicon-mark-github" viewBox="0 0 16 16" version="1.1" width="32" aria-hidden="true"><path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0 0 16 8c0-4.42-3.58-8-8-8z"/></svg>
      </a>

    </div>

    <div class="HeaderMenu HeaderMenu--bright d-flex flex-justify-between flex-auto">
        <nav class="mt-0">
          <ul class="d-flex list-style-none">
              <li class="ml-2">
                <a class="js-selected-navigation-item HeaderNavlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:features" data-selected-links="/features /features/project-management /features/code-review /features/project-management /features/integrations /features" href="/features">
                  Features
</a>              </li>
              <li class="ml-4">
                <a class="js-selected-navigation-item HeaderNavlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:business" data-selected-links="/business /business/security /business/customers /business" href="/business">
                  Business
</a>              </li>

              <li class="ml-4">
                <a class="js-selected-navigation-item HeaderNavlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:explore" data-selected-links="/explore /trending /trending/developers /integrations /integrations/feature/code /integrations/feature/collaborate /integrations/feature/ship showcases showcases_search showcases_landing /explore" href="/explore">
                  Explore
</a>              </li>

              <li class="ml-4">
                    <a class="js-selected-navigation-item HeaderNavlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:marketplace" data-selected-links=" /marketplace" href="/marketplace">
                      Marketplace
</a>              </li>
              <li class="ml-4">
                <a class="js-selected-navigation-item HeaderNavlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:pricing" data-selected-links="/pricing /pricing/developer /pricing/team /pricing/business-hosted /pricing/business-enterprise /pricing" href="/pricing">
                  Pricing
</a>              </li>
          </ul>
        </nav>

      <div class="d-flex">
          <div class="d-lg-flex flex-items-center mr-3">
            <div class="header-search scoped-search site-scoped-search js-site-search" role="search">
  <!-- '"` --><!-- </textarea></xmp> --></option></form><form class="js-site-search-form" data-scoped-search-url="/jaridmargolin/formatter.js/search" data-unscoped-search-url="/search" action="/jaridmargolin/formatter.js/search" accept-charset="UTF-8" method="get"><input name="utf8" type="hidden" value="&#x2713;" />
    <label class="form-control header-search-wrapper  js-chromeless-input-container">
        <a class="header-search-scope no-underline" href="/jaridmargolin/formatter.js/commits">This repository</a>
      <input type="text"
        class="form-control header-search-input  js-site-search-focus js-site-search-field is-clearable"
        data-hotkey="s,/"
        name="q"
        value=""
        placeholder="Search"
        aria-label="Search this repository"
        data-unscoped-placeholder="Search GitHub"
        data-scoped-placeholder="Search"
        autocapitalize="off"
        >
        <input type="hidden" class="js-site-search-type-field" name="type" >
    </label>
</form></div>

          </div>

        <span class="d-inline-block">
            <div class="HeaderNavlink px-0 py-2 m-0">
              <a class="text-bold text-white no-underline" href="/login?return_to=%2Fjaridmargolin%2Fformatter.js%2Fcommits%2Fmaster%2FREADME.md" data-ga-click="(Logged out) Header, clicked Sign in, text:sign-in">Sign in</a>
                <span class="text-gray">or</span>
                <a class="text-bold text-white no-underline" href="/join?source=header-repo" data-ga-click="(Logged out) Header, clicked Sign up, text:sign-up">Sign up</a>
            </div>
        </span>
      </div>
    </div>
  </div>
</header>

  </div>

  <div id="start-of-content" class="show-on-focus"></div>

    <div id="js-flash-container">
</div>



  <div role="main" class="application-main ">
        <div itemscope itemtype="http://schema.org/SoftwareSourceCode" class="">
    <div id="js-repo-pjax-container" data-pjax-container >
      





  <div class="pagehead repohead instapaper_ignore readability-menu experiment-repo-nav  ">
    <div class="repohead-details-container clearfix container">

      <ul class="pagehead-actions">
  <li>
      <a href="/login?return_to=%2Fjaridmargolin%2Fformatter.js"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to watch a repository" rel="nofollow">
    <svg class="octicon octicon-eye" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M8.06 2C3 2 0 8 0 8s3 6 8.06 6C13 14 16 8 16 8s-3-6-7.94-6zM8 12c-2.2 0-4-1.78-4-4 0-2.2 1.8-4 4-4 2.22 0 4 1.8 4 4 0 2.22-1.78 4-4 4zm2-4c0 1.11-.89 2-2 2-1.11 0-2-.89-2-2 0-1.11.89-2 2-2 1.11 0 2 .89 2 2z"/></svg>
    Watch
  </a>
  <a class="social-count" href="/jaridmargolin/formatter.js/watchers"
     aria-label="83 users are watching this repository">
    83
  </a>

  </li>

  <li>
      <a href="/login?return_to=%2Fjaridmargolin%2Fformatter.js"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to star a repository" rel="nofollow">
    <svg class="octicon octicon-star" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M14 6l-4.9-.64L7 1 4.9 5.36 0 6l3.6 3.26L2.67 14 7 11.67 11.33 14l-.93-4.74z"/></svg>
    Star
  </a>

    <a class="social-count js-social-count" href="/jaridmargolin/formatter.js/stargazers"
      aria-label="2541 users starred this repository">
      2,541
    </a>

  </li>

  <li>
      <a href="/login?return_to=%2Fjaridmargolin%2Fformatter.js"
        class="btn btn-sm btn-with-count tooltipped tooltipped-n"
        aria-label="You must be signed in to fork a repository" rel="nofollow">
        <svg class="octicon octicon-repo-forked" viewBox="0 0 10 16" version="1.1" width="10" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M8 1a1.993 1.993 0 0 0-1 3.72V6L5 8 3 6V4.72A1.993 1.993 0 0 0 2 1a1.993 1.993 0 0 0-1 3.72V6.5l3 3v1.78A1.993 1.993 0 0 0 5 15a1.993 1.993 0 0 0 1-3.72V9.5l3-3V4.72A1.993 1.993 0 0 0 8 1zM2 4.2C1.34 4.2.8 3.65.8 3c0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zm3 10c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zm3-10c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2z"/></svg>
        Fork
      </a>

    <a href="/jaridmargolin/formatter.js/network" class="social-count"
       aria-label="250 users forked this repository">
      250
    </a>
  </li>
</ul>

      <h1 class="public ">
  <svg class="octicon octicon-repo" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M4 9H3V8h1v1zm0-3H3v1h1V6zm0-2H3v1h1V4zm0-2H3v1h1V2zm8-1v12c0 .55-.45 1-1 1H6v2l-1.5-1.5L3 16v-2H1c-.55 0-1-.45-1-1V1c0-.55.45-1 1-1h10c.55 0 1 .45 1 1zm-1 10H1v2h2v-1h3v1h5v-2zm0-10H2v9h9V1z"/></svg>
  <span class="author" itemprop="author"><a class="url fn" rel="author" href="/jaridmargolin">jaridmargolin</a></span><!--
--><span class="path-divider">/</span><!--
--><strong itemprop="name"><a data-pjax="#js-repo-pjax-container" href="/jaridmargolin/formatter.js">formatter.js</a></strong>

</h1>

    </div>
    
<nav class="reponav js-repo-nav js-sidenav-container-pjax container"
     itemscope
     itemtype="http://schema.org/BreadcrumbList"
     role="navigation"
     data-pjax="#js-repo-pjax-container">

  <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
    <a class="js-selected-navigation-item selected reponav-item" itemprop="url" data-hotkey="g c" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches repo_packages /jaridmargolin/formatter.js" href="/jaridmargolin/formatter.js">
      <svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg>
      <span itemprop="name">Code</span>
      <meta itemprop="position" content="1">
</a>  </span>

    <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
      <a itemprop="url" data-hotkey="g i" class="js-selected-navigation-item reponav-item" data-selected-links="repo_issues repo_labels repo_milestones /jaridmargolin/formatter.js/issues" href="/jaridmargolin/formatter.js/issues">
        <svg class="octicon octicon-issue-opened" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7 2.3c3.14 0 5.7 2.56 5.7 5.7s-2.56 5.7-5.7 5.7A5.71 5.71 0 0 1 1.3 8c0-3.14 2.56-5.7 5.7-5.7zM7 1C3.14 1 0 4.14 0 8s3.14 7 7 7 7-3.14 7-7-3.14-7-7-7zm1 3H6v5h2V4zm0 6H6v2h2v-2z"/></svg>
        <span itemprop="name">Issues</span>
        <span class="Counter">38</span>
        <meta itemprop="position" content="2">
</a>    </span>

  <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
    <a data-hotkey="g p" itemprop="url" class="js-selected-navigation-item reponav-item" data-selected-links="repo_pulls checks /jaridmargolin/formatter.js/pulls" href="/jaridmargolin/formatter.js/pulls">
      <svg class="octicon octicon-git-pull-request" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M11 11.28V5c-.03-.78-.34-1.47-.94-2.06C9.46 2.35 8.78 2.03 8 2H7V0L4 3l3 3V4h1c.27.02.48.11.69.31.21.2.3.42.31.69v6.28A1.993 1.993 0 0 0 10 15a1.993 1.993 0 0 0 1-3.72zm-1 2.92c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zM4 3c0-1.11-.89-2-2-2a1.993 1.993 0 0 0-1 3.72v6.56A1.993 1.993 0 0 0 2 15a1.993 1.993 0 0 0 1-3.72V4.72c.59-.34 1-.98 1-1.72zm-.8 10c0 .66-.55 1.2-1.2 1.2-.65 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2zM2 4.2C1.34 4.2.8 3.65.8 3c0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2z"/></svg>
      <span itemprop="name">Pull requests</span>
      <span class="Counter">14</span>
      <meta itemprop="position" content="3">
</a>  </span>

    <a data-hotkey="g b" class="js-selected-navigation-item reponav-item" data-selected-links="repo_projects new_repo_project repo_project /jaridmargolin/formatter.js/projects" href="/jaridmargolin/formatter.js/projects">
      <svg class="octicon octicon-project" viewBox="0 0 15 16" version="1.1" width="15" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M10 12h3V2h-3v10zm-4-2h3V2H6v8zm-4 4h3V2H2v12zm-1 1h13V1H1v14zM14 0H1a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h13a1 1 0 0 0 1-1V1a1 1 0 0 0-1-1z"/></svg>
      Projects
      <span class="Counter" >0</span>
</a>


  <a class="js-selected-navigation-item reponav-item" data-selected-links="repo_graphs repo_contributors dependency_graph pulse /jaridmargolin/formatter.js/pulse" href="/jaridmargolin/formatter.js/pulse">
    <svg class="octicon octicon-graph" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M16 14v1H0V0h1v14h15zM5 13H3V8h2v5zm4 0H7V3h2v10zm4 0h-2V6h2v7z"/></svg>
    Insights
</a>

</nav>


  </div>

<div class="container new-discussion-timeline experiment-repo-nav  ">
  <div class="repository-content ">

    
    <div class="file-navigation">
      <div class="breadcrumb">
        History for <span class="repo-root js-repo-root"><span class="js-path-segment"><a data-pjax="true" href="/jaridmargolin/formatter.js/commits/master"><span>formatter.js</span></a></span></span><span class="separator">/</span><strong class="final-path">README.md</strong>
      </div>
    </div>

    <div class="commits-listing commits-listing-padded js-navigation-container js-active-navigation-container" data-navigation-scroll="page">
        <div class="commit-group-title">
          <svg class="octicon octicon-git-commit" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Mar 17, 2014
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
    data-channel="repo:12876724:commit:8ce0d4892511c4cf93c5b24440cd236faec6b567"
    data-url="/_render_node/MDY6Q29tbWl0MTI4NzY3MjQ6OGNlMGQ0ODkyNTExYzRjZjkzYzViMjQ0NDBjZDIzNmZhZWM2YjU2Nw==/commits/commits_list_item">
  
<div class="table-list-cell">
  <p class="commit-title h5 mb-1 text-gray-dark ">
      <a title="Add multi-pattern support." class="message" data-pjax="true" href="/jaridmargolin/formatter.js/commit/8ce0d4892511c4cf93c5b24440cd236faec6b567#diff-04c6e90faac2675aa89e2176d2eec7d8">Add multi-pattern support.</a>

  </p>

  <div class="commit-meta commit-author-section no-wrap d-flex flex-items-center mt-1">
    
<div class="AvatarStack flex-self-start AvatarStack--two">
  <div class="AvatarStack-body" aria-label="mickeyreiss and braintreeps (non-author committer)">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="47405" href="/mickeyreiss">
          <img height="20" width="20" alt="@mickeyreiss" src="https://avatars2.githubusercontent.com/u/47405?s=60&amp;v=4" />
</a>
        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="200407" href="/braintreeps">
          <img height="20" width="20" alt="@braintreeps" src="https://avatars3.githubusercontent.com/u/200407?s=60&amp;v=4" />
</a>  </div>
</div>

    <div>
      
      <a href="/jaridmargolin/formatter.js/commits?author=mickeyreiss"
     class="commit-author tooltipped tooltipped-s user-mention"
     aria-label="View all commits by mickeyreiss">mickeyreiss</a>


  authored and   <a href="/jaridmargolin/formatter.js/commits?author=braintreeps"
     class="commit-author tooltipped tooltipped-s user-mention"
     aria-label="View all commits by braintreeps">braintreeps</a>

  committed
  <relative-time datetime="2014-03-14T17:54:51Z">Mar 14, 2014</relative-time>

    </div>
  </div>


</div>

<div class="commit-links-cell table-list-cell">

  


  <div class="commit-links-group BtnGroup">
    <clipboard-copy
        value="8ce0d4892511c4cf93c5b24440cd236faec6b567"
        aria-label="Copy the full SHA"
        class="btn btn-outline BtnGroup-item tooltipped tooltipped-s"
        copied-label="Copied!">
      <svg class="octicon octicon-clippy" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg>
    </clipboard-copy>

    <a href="/jaridmargolin/formatter.js/commit/8ce0d4892511c4cf93c5b24440cd236faec6b567#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
      8ce0d48
    </a>
  </div>
  <a href="/jaridmargolin/formatter.js/tree/8ce0d4892511c4cf93c5b24440cd236faec6b567" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
</div>

</li>

        </ol>
        <div class="commit-group-title">
          <svg class="octicon octicon-git-commit" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Dec 1, 2013
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
    data-channel="repo:12876724:commit:31562b33786acb35d8018f4f5ba0de74fe52cd52"
    data-url="/_render_node/MDY6Q29tbWl0MTI4NzY3MjQ6MzE1NjJiMzM3ODZhY2IzNWQ4MDE4ZjRmNWJhMGRlNzRmZTUyY2Q1Mg==/commits/commits_list_item">
  
<div class="table-list-cell">
  <p class="commit-title h5 mb-1 text-gray-dark ">
      <a title="Add method to Jquery lib. Updated README" class="message" data-pjax="true" href="/jaridmargolin/formatter.js/commit/31562b33786acb35d8018f4f5ba0de74fe52cd52#diff-04c6e90faac2675aa89e2176d2eec7d8">Add method to Jquery lib. Updated README</a>

  </p>

  <div class="commit-meta commit-author-section no-wrap d-flex flex-items-center mt-1">
    
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

    <div>
      
      <a href="/jaridmargolin/formatter.js/commits?author=jaridmargolin"
     class="commit-author tooltipped tooltipped-s user-mention"
     aria-label="View all commits by jaridmargolin">jaridmargolin</a>


  committed
  <relative-time datetime="2013-12-01T06:28:18Z">Dec 1, 2013</relative-time>

    </div>
      <div class="commit-indicator">
        
  <div class="commit-build-statuses">
      <a class="text-green tooltipped tooltipped-e"
         aria-label="Success: The Travis CI build passed"
         href="https://travis-ci.org/firstopinion/formatter.js/builds/14756972">
        <svg class="octicon octicon-check v-align-middle" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5z"/></svg>
      </a>
  </div>

      </div>
  </div>


</div>

<div class="commit-links-cell table-list-cell">

  


  <div class="commit-links-group BtnGroup">
    <clipboard-copy
        value="31562b33786acb35d8018f4f5ba0de74fe52cd52"
        aria-label="Copy the full SHA"
        class="btn btn-outline BtnGroup-item tooltipped tooltipped-s"
        copied-label="Copied!">
      <svg class="octicon octicon-clippy" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg>
    </clipboard-copy>

    <a href="/jaridmargolin/formatter.js/commit/31562b33786acb35d8018f4f5ba0de74fe52cd52#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
      31562b3
    </a>
  </div>
  <a href="/jaridmargolin/formatter.js/tree/31562b33786acb35d8018f4f5ba0de74fe52cd52" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
</div>

</li>

        </ol>
        <div class="commit-group-title">
          <svg class="octicon octicon-git-commit" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Nov 4, 2013
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
    data-channel="repo:12876724:commit:5b0b5f9715703f4c33d32de688f636e5e0b34d7e"
    data-url="/_render_node/MDY6Q29tbWl0MTI4NzY3MjQ6NWIwYjVmOTcxNTcwM2Y0YzMzZDMyZGU2ODhmNjM2ZTVlMGIzNGQ3ZQ==/commits/commits_list_item">
  
<div class="table-list-cell">
  <p class="commit-title h5 mb-1 text-gray-dark ">
      <a title="Fixes small typo in README" class="message" data-pjax="true" href="/jaridmargolin/formatter.js/commit/5b0b5f9715703f4c33d32de688f636e5e0b34d7e#diff-04c6e90faac2675aa89e2176d2eec7d8">Fixes small typo in README</a>

  </p>

  <div class="commit-meta commit-author-section no-wrap d-flex flex-items-center mt-1">
    
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="Federico Baña">

        <img src="https://camo.githubusercontent.com/4a38264943fcd52d02eb32193be354cf2a2d626b/68747470733a2f2f322e67726176617461722e636f6d2f6176617461722f33653932393736343662396362326434343966646666643836313532366232303f643d68747470732533412532462532466173736574732d63646e2e6769746875622e636f6d253246696d6167657325324667726176617461727325324667726176617461722d757365722d3432302e706e6726723d6726733d3430" width="20" height="20" class="avatar" alt="Federico Baña">
  </div>
</div>

    <div>
      
        <span class="commit-author user-mention">Federico Baña</span>


  committed
  <relative-time datetime="2013-11-04T12:48:08Z">Nov 4, 2013</relative-time>

    </div>
      <div class="commit-indicator">
        
  <div class="commit-build-statuses">
      <a class="text-green tooltipped tooltipped-e"
         aria-label="Success: The Travis CI build passed"
         href="https://travis-ci.org/firstopinion/formatter.js/builds/13470457">
        <svg class="octicon octicon-check v-align-middle" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5z"/></svg>
      </a>
  </div>

      </div>
  </div>


</div>

<div class="commit-links-cell table-list-cell">

  


  <div class="commit-links-group BtnGroup">
    <clipboard-copy
        value="5b0b5f9715703f4c33d32de688f636e5e0b34d7e"
        aria-label="Copy the full SHA"
        class="btn btn-outline BtnGroup-item tooltipped tooltipped-s"
        copied-label="Copied!">
      <svg class="octicon octicon-clippy" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg>
    </clipboard-copy>

    <a href="/jaridmargolin/formatter.js/commit/5b0b5f9715703f4c33d32de688f636e5e0b34d7e#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
      5b0b5f9
    </a>
  </div>
  <a href="/jaridmargolin/formatter.js/tree/5b0b5f9715703f4c33d32de688f636e5e0b34d7e" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
</div>

</li>

            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
    data-channel="repo:12876724:commit:65a088c11184e31db5d74552d28477268e4a82d8"
    data-url="/_render_node/MDY6Q29tbWl0MTI4NzY3MjQ6NjVhMDg4YzExMTg0ZTMxZGI1ZDc0NTUyZDI4NDc3MjY4ZTRhODJkOA==/commits/commits_list_item">
  
<div class="table-list-cell">
  <p class="commit-title h5 mb-1 text-gray-dark ">
      <a title="update order of sections in README.md" class="message" data-pjax="true" href="/jaridmargolin/formatter.js/commit/65a088c11184e31db5d74552d28477268e4a82d8#diff-04c6e90faac2675aa89e2176d2eec7d8">update order of sections in README.md</a>

  </p>

  <div class="commit-meta commit-author-section no-wrap d-flex flex-items-center mt-1">
    
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

    <div>
      
      <a href="/jaridmargolin/formatter.js/commits?author=jaridmargolin"
     class="commit-author tooltipped tooltipped-s user-mention"
     aria-label="View all commits by jaridmargolin">jaridmargolin</a>


  committed
  <relative-time datetime="2013-11-04T10:59:29Z">Nov 4, 2013</relative-time>

    </div>
      <div class="commit-indicator">
        
  <div class="commit-build-statuses">
      <a class="text-green tooltipped tooltipped-e"
         aria-label="Success: The Travis CI build passed"
         href="https://travis-ci.org/firstopinion/formatter.js/builds/13466973">
        <svg class="octicon octicon-check v-align-middle" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5z"/></svg>
      </a>
  </div>

      </div>
  </div>


</div>

<div class="commit-links-cell table-list-cell">

  


  <div class="commit-links-group BtnGroup">
    <clipboard-copy
        value="65a088c11184e31db5d74552d28477268e4a82d8"
        aria-label="Copy the full SHA"
        class="btn btn-outline BtnGroup-item tooltipped tooltipped-s"
        copied-label="Copied!">
      <svg class="octicon octicon-clippy" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg>
    </clipboard-copy>

    <a href="/jaridmargolin/formatter.js/commit/65a088c11184e31db5d74552d28477268e4a82d8#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
      65a088c
    </a>
  </div>
  <a href="/jaridmargolin/formatter.js/tree/65a088c11184e31db5d74552d28477268e4a82d8" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
</div>

</li>

            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
    data-channel="repo:12876724:commit:d9dbbfbf9766c759efdb3d8f00bbe4f69a633d30"
    data-url="/_render_node/MDY6Q29tbWl0MTI4NzY3MjQ6ZDlkYmJmYmY5NzY2Yzc1OWVmZGIzZDhmMDBiYmU0ZjY5YTYzM2QzMA==/commits/commits_list_item">
  
<div class="table-list-cell">
  <p class="commit-title h5 mb-1 text-gray-dark ">
      <span aria-label="This commit closes issue #10." class="issue-keyword tooltipped tooltipped-se"><a title="Close #10 - Add resetPattern method" class="message" data-pjax="true" href="/jaridmargolin/formatter.js/commit/d9dbbfbf9766c759efdb3d8f00bbe4f69a633d30#diff-04c6e90faac2675aa89e2176d2eec7d8">Close</a></span> <a href="https://github.com/firstopinion/formatter.js/issues/10" class="issue-link js-issue-link" data-error-text="Failed to load issue title" data-id="21976039" data-permission-text="Issue title is private" data-url="https://github.com/firstopinion/formatter.js/issues/10">#10</a> <a title="Close #10 - Add resetPattern method" class="message" data-pjax="true" href="/jaridmargolin/formatter.js/commit/d9dbbfbf9766c759efdb3d8f00bbe4f69a633d30#diff-04c6e90faac2675aa89e2176d2eec7d8">- Add resetPattern method</a>

  </p>

  <div class="commit-meta commit-author-section no-wrap d-flex flex-items-center mt-1">
    
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

    <div>
      
      <a href="/jaridmargolin/formatter.js/commits?author=jaridmargolin"
     class="commit-author tooltipped tooltipped-s user-mention"
     aria-label="View all commits by jaridmargolin">jaridmargolin</a>


  committed
  <relative-time datetime="2013-11-04T10:44:50Z">Nov 4, 2013</relative-time>

    </div>
      <div class="commit-indicator">
        
  <div class="commit-build-statuses">
      <a class="text-green tooltipped tooltipped-e"
         aria-label="Success: The Travis CI build passed"
         href="https://travis-ci.org/firstopinion/formatter.js/builds/13466531">
        <svg class="octicon octicon-check v-align-middle" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5z"/></svg>
      </a>
  </div>

      </div>
  </div>


</div>

<div class="commit-links-cell table-list-cell">

  


  <div class="commit-links-group BtnGroup">
    <clipboard-copy
        value="d9dbbfbf9766c759efdb3d8f00bbe4f69a633d30"
        aria-label="Copy the full SHA"
        class="btn btn-outline BtnGroup-item tooltipped tooltipped-s"
        copied-label="Copied!">
      <svg class="octicon octicon-clippy" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg>
    </clipboard-copy>

    <a href="/jaridmargolin/formatter.js/commit/d9dbbfbf9766c759efdb3d8f00bbe4f69a633d30#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
      d9dbbfb
    </a>
  </div>
  <a href="/jaridmargolin/formatter.js/tree/d9dbbfbf9766c759efdb3d8f00bbe4f69a633d30" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
</div>

</li>

        </ol>
        <div class="commit-group-title">
          <svg class="octicon octicon-git-commit" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Oct 29, 2013
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
    data-channel="repo:12876724:commit:844e7a0621982e244439e27203060183ad751b95"
    data-url="/_render_node/MDY6Q29tbWl0MTI4NzY3MjQ6ODQ0ZTdhMDYyMTk4MmUyNDQ0MzllMjcyMDMwNjAxODNhZDc1MWI5NQ==/commits/commits_list_item">
  
<div class="table-list-cell">
  <p class="commit-title h5 mb-1 text-gray-dark ">
      
<span aria-label="This commit closes issue #5." class="issue-keyword tooltipped tooltipped-se"><a title="Fix #5" class="message" data-pjax="true" href="/jaridmargolin/formatter.js/commit/844e7a0621982e244439e27203060183ad751b95#diff-04c6e90faac2675aa89e2176d2eec7d8">Fix</a></span> <a href="https://github.com/firstopinion/formatter.js/issues/5" class="issue-link js-issue-link" data-error-text="Failed to load issue title" data-id="21773234" data-permission-text="Issue title is private" data-url="https://github.com/firstopinion/formatter.js/issues/5">#5</a>


  </p>

  <div class="commit-meta commit-author-section no-wrap d-flex flex-items-center mt-1">
    
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

    <div>
      
      <a href="/jaridmargolin/formatter.js/commits?author=jaridmargolin"
     class="commit-author tooltipped tooltipped-s user-mention"
     aria-label="View all commits by jaridmargolin">jaridmargolin</a>


  committed
  <relative-time datetime="2013-10-29T17:35:33Z">Oct 29, 2013</relative-time>

    </div>
      <div class="commit-indicator">
        
  <div class="commit-build-statuses">
      <a class="text-green tooltipped tooltipped-e"
         aria-label="Success: The Travis CI build passed"
         href="https://travis-ci.org/firstopinion/formatter.js/builds/13221234">
        <svg class="octicon octicon-check v-align-middle" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5z"/></svg>
      </a>
  </div>

      </div>
  </div>


</div>

<div class="commit-links-cell table-list-cell">

  


  <div class="commit-links-group BtnGroup">
    <clipboard-copy
        value="844e7a0621982e244439e27203060183ad751b95"
        aria-label="Copy the full SHA"
        class="btn btn-outline BtnGroup-item tooltipped tooltipped-s"
        copied-label="Copied!">
      <svg class="octicon octicon-clippy" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg>
    </clipboard-copy>

    <a href="/jaridmargolin/formatter.js/commit/844e7a0621982e244439e27203060183ad751b95#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
      844e7a0
    </a>
  </div>
  <a href="/jaridmargolin/formatter.js/tree/844e7a0621982e244439e27203060183ad751b95" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
</div>

</li>

            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
    data-channel="repo:12876724:commit:29ba01c8335e498e0c25e0f5ff4db1c17cccdcf3"
    data-url="/_render_node/MDY6Q29tbWl0MTI4NzY3MjQ6MjliYTAxYzgzMzVlNDk4ZTBjMjVlMGY1ZmY0ZGIxYzE3Y2NjZGNmMw==/commits/commits_list_item">
  
<div class="table-list-cell">
  <p class="commit-title h5 mb-1 text-gray-dark ">
      
<span aria-label="This commit closes issue #3." class="issue-keyword tooltipped tooltipped-se"><a title="resolve #3" class="message" data-pjax="true" href="/jaridmargolin/formatter.js/commit/29ba01c8335e498e0c25e0f5ff4db1c17cccdcf3#diff-04c6e90faac2675aa89e2176d2eec7d8">resolve</a></span> <a href="https://github.com/firstopinion/formatter.js/issues/3" class="issue-link js-issue-link" data-error-text="Failed to load issue title" data-id="21734127" data-permission-text="Issue title is private" data-url="https://github.com/firstopinion/formatter.js/issues/3">#3</a>


  </p>

  <div class="commit-meta commit-author-section no-wrap d-flex flex-items-center mt-1">
    
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

    <div>
      
      <a href="/jaridmargolin/formatter.js/commits?author=jaridmargolin"
     class="commit-author tooltipped tooltipped-s user-mention"
     aria-label="View all commits by jaridmargolin">jaridmargolin</a>


  committed
  <relative-time datetime="2013-10-29T08:56:53Z">Oct 29, 2013</relative-time>

    </div>
      <div class="commit-indicator">
        
  <div class="commit-build-statuses">
      <a class="text-green tooltipped tooltipped-e"
         aria-label="Success: The Travis CI build passed"
         href="https://travis-ci.org/firstopinion/formatter.js/builds/13197011">
        <svg class="octicon octicon-check v-align-middle" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5z"/></svg>
      </a>
  </div>

      </div>
  </div>


</div>

<div class="commit-links-cell table-list-cell">

  


  <div class="commit-links-group BtnGroup">
    <clipboard-copy
        value="29ba01c8335e498e0c25e0f5ff4db1c17cccdcf3"
        aria-label="Copy the full SHA"
        class="btn btn-outline BtnGroup-item tooltipped tooltipped-s"
        copied-label="Copied!">
      <svg class="octicon octicon-clippy" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg>
    </clipboard-copy>

    <a href="/jaridmargolin/formatter.js/commit/29ba01c8335e498e0c25e0f5ff4db1c17cccdcf3#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
      29ba01c
    </a>
  </div>
  <a href="/jaridmargolin/formatter.js/tree/29ba01c8335e498e0c25e0f5ff4db1c17cccdcf3" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
</div>

</li>

        </ol>
        <div class="commit-group-title">
          <svg class="octicon octicon-git-commit" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Oct 22, 2013
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
    data-channel="repo:12876724:commit:d780ea15885dd7df9f479a227454cad13f2e0850"
    data-url="/_render_node/MDY6Q29tbWl0MTI4NzY3MjQ6ZDc4MGVhMTU4ODVkZDdkZjlmNDc5YTIyNzQ1NGNhZDEzZjJlMDg1MA==/commits/commits_list_item">
  
<div class="table-list-cell">
  <p class="commit-title h5 mb-1 text-gray-dark ">
      <a title="Add demos to README" class="message" data-pjax="true" href="/jaridmargolin/formatter.js/commit/d780ea15885dd7df9f479a227454cad13f2e0850#diff-04c6e90faac2675aa89e2176d2eec7d8">Add demos to README</a>

  </p>

  <div class="commit-meta commit-author-section no-wrap d-flex flex-items-center mt-1">
    
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

    <div>
      
      <a href="/jaridmargolin/formatter.js/commits?author=jaridmargolin"
     class="commit-author tooltipped tooltipped-s user-mention"
     aria-label="View all commits by jaridmargolin">jaridmargolin</a>


  committed
  <relative-time datetime="2013-10-22T00:30:20Z">Oct 22, 2013</relative-time>

    </div>
      <div class="commit-indicator">
        
  <div class="commit-build-statuses">
      <a class="text-green tooltipped tooltipped-e"
         aria-label="Success: The Travis CI build passed"
         href="https://travis-ci.org/firstopinion/formatter.js/builds/12856355">
        <svg class="octicon octicon-check v-align-middle" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5z"/></svg>
      </a>
  </div>

      </div>
  </div>


</div>

<div class="commit-links-cell table-list-cell">

  


  <div class="commit-links-group BtnGroup">
    <clipboard-copy
        value="d780ea15885dd7df9f479a227454cad13f2e0850"
        aria-label="Copy the full SHA"
        class="btn btn-outline BtnGroup-item tooltipped tooltipped-s"
        copied-label="Copied!">
      <svg class="octicon octicon-clippy" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg>
    </clipboard-copy>

    <a href="/jaridmargolin/formatter.js/commit/d780ea15885dd7df9f479a227454cad13f2e0850#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
      d780ea1
    </a>
  </div>
  <a href="/jaridmargolin/formatter.js/tree/d780ea15885dd7df9f479a227454cad13f2e0850" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
</div>

</li>

        </ol>
        <div class="commit-group-title">
          <svg class="octicon octicon-git-commit" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Oct 21, 2013
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
    data-channel="repo:12876724:commit:a1bccecc0b9d3ae9dcae68f0ced5b7674c9f2e01"
    data-url="/_render_node/MDY6Q29tbWl0MTI4NzY3MjQ6YTFiY2NlY2MwYjlkM2FlOWRjYWU2OGYwY2VkNWI3Njc0YzlmMmUwMQ==/commits/commits_list_item">
  
<div class="table-list-cell">
  <p class="commit-title h5 mb-1 text-gray-dark ">
      <a title="README to reflect updates" class="message" data-pjax="true" href="/jaridmargolin/formatter.js/commit/a1bccecc0b9d3ae9dcae68f0ced5b7674c9f2e01#diff-04c6e90faac2675aa89e2176d2eec7d8">README to reflect updates</a>

  </p>

  <div class="commit-meta commit-author-section no-wrap d-flex flex-items-center mt-1">
    
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

    <div>
      
      <a href="/jaridmargolin/formatter.js/commits?author=jaridmargolin"
     class="commit-author tooltipped tooltipped-s user-mention"
     aria-label="View all commits by jaridmargolin">jaridmargolin</a>


  committed
  <relative-time datetime="2013-10-21T23:52:44Z">Oct 21, 2013</relative-time>

    </div>
      <div class="commit-indicator">
        
  <div class="commit-build-statuses">
      <a class="text-green tooltipped tooltipped-e"
         aria-label="Success: The Travis CI build passed"
         href="https://travis-ci.org/firstopinion/formatter.js/builds/12855093">
        <svg class="octicon octicon-check v-align-middle" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5z"/></svg>
      </a>
  </div>

      </div>
  </div>


</div>

<div class="commit-links-cell table-list-cell">

  


  <div class="commit-links-group BtnGroup">
    <clipboard-copy
        value="a1bccecc0b9d3ae9dcae68f0ced5b7674c9f2e01"
        aria-label="Copy the full SHA"
        class="btn btn-outline BtnGroup-item tooltipped tooltipped-s"
        copied-label="Copied!">
      <svg class="octicon octicon-clippy" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg>
    </clipboard-copy>

    <a href="/jaridmargolin/formatter.js/commit/a1bccecc0b9d3ae9dcae68f0ced5b7674c9f2e01#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
      a1bccec
    </a>
  </div>
  <a href="/jaridmargolin/formatter.js/tree/a1bccecc0b9d3ae9dcae68f0ced5b7674c9f2e01" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
</div>

</li>

            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
    data-channel="repo:12876724:commit:dff4d24bacd32187060995f3ce29f32d9df191fb"
    data-url="/_render_node/MDY6Q29tbWl0MTI4NzY3MjQ6ZGZmNGQyNGJhY2QzMjE4NzA2MDk5NWYzY2UyOWYzMmQ5ZGYxOTFmYg==/commits/commits_list_item">
  
<div class="table-list-cell">
  <p class="commit-title h5 mb-1 text-gray-dark ">
      <a title="Add support for jquery" class="message" data-pjax="true" href="/jaridmargolin/formatter.js/commit/dff4d24bacd32187060995f3ce29f32d9df191fb#diff-04c6e90faac2675aa89e2176d2eec7d8">Add support for jquery</a>

  </p>

  <div class="commit-meta commit-author-section no-wrap d-flex flex-items-center mt-1">
    
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

    <div>
      
      <a href="/jaridmargolin/formatter.js/commits?author=jaridmargolin"
     class="commit-author tooltipped tooltipped-s user-mention"
     aria-label="View all commits by jaridmargolin">jaridmargolin</a>


  committed
  <relative-time datetime="2013-10-21T23:50:02Z">Oct 21, 2013</relative-time>

    </div>
      <div class="commit-indicator">
        
  <div class="commit-build-statuses">
      <a class="text-green tooltipped tooltipped-e"
         aria-label="Success: The Travis CI build passed"
         href="https://travis-ci.org/firstopinion/formatter.js/builds/12854984">
        <svg class="octicon octicon-check v-align-middle" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5z"/></svg>
      </a>
  </div>

      </div>
  </div>


</div>

<div class="commit-links-cell table-list-cell">

  


  <div class="commit-links-group BtnGroup">
    <clipboard-copy
        value="dff4d24bacd32187060995f3ce29f32d9df191fb"
        aria-label="Copy the full SHA"
        class="btn btn-outline BtnGroup-item tooltipped tooltipped-s"
        copied-label="Copied!">
      <svg class="octicon octicon-clippy" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg>
    </clipboard-copy>

    <a href="/jaridmargolin/formatter.js/commit/dff4d24bacd32187060995f3ce29f32d9df191fb#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
      dff4d24
    </a>
  </div>
  <a href="/jaridmargolin/formatter.js/tree/dff4d24bacd32187060995f3ce29f32d9df191fb" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
</div>

</li>

        </ol>
        <div class="commit-group-title">
          <svg class="octicon octicon-git-commit" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Oct 7, 2013
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
    data-channel="repo:12876724:commit:48518ea76fb0191643e14230c130b0290e9278a9"
    data-url="/_render_node/MDY6Q29tbWl0MTI4NzY3MjQ6NDg1MThlYTc2ZmIwMTkxNjQzZTE0MjMwYzEzMGIwMjkwZTkyNzhhOQ==/commits/commits_list_item">
  
<div class="table-list-cell">
  <p class="commit-title h5 mb-1 text-gray-dark ">
      <a title="Multiple character caret position bug fix. Small refractor" class="message" data-pjax="true" href="/jaridmargolin/formatter.js/commit/48518ea76fb0191643e14230c130b0290e9278a9#diff-04c6e90faac2675aa89e2176d2eec7d8">Multiple character caret position bug fix. Small refractor</a>

  </p>

  <div class="commit-meta commit-author-section no-wrap d-flex flex-items-center mt-1">
    
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

    <div>
      
      <a href="/jaridmargolin/formatter.js/commits?author=jaridmargolin"
     class="commit-author tooltipped tooltipped-s user-mention"
     aria-label="View all commits by jaridmargolin">jaridmargolin</a>


  committed
  <relative-time datetime="2013-10-07T22:43:22Z">Oct 7, 2013</relative-time>

    </div>
      <div class="commit-indicator">
        
  <div class="commit-build-statuses">
      <a class="text-green tooltipped tooltipped-e"
         aria-label="Success: The Travis CI build passed"
         href="https://travis-ci.org/firstopinion/formatter.js/builds/12252760">
        <svg class="octicon octicon-check v-align-middle" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5z"/></svg>
      </a>
  </div>

      </div>
  </div>


</div>

<div class="commit-links-cell table-list-cell">

  


  <div class="commit-links-group BtnGroup">
    <clipboard-copy
        value="48518ea76fb0191643e14230c130b0290e9278a9"
        aria-label="Copy the full SHA"
        class="btn btn-outline BtnGroup-item tooltipped tooltipped-s"
        copied-label="Copied!">
      <svg class="octicon octicon-clippy" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg>
    </clipboard-copy>

    <a href="/jaridmargolin/formatter.js/commit/48518ea76fb0191643e14230c130b0290e9278a9#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
      48518ea
    </a>
  </div>
  <a href="/jaridmargolin/formatter.js/tree/48518ea76fb0191643e14230c130b0290e9278a9" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
</div>

</li>

        </ol>
        <div class="commit-group-title">
          <svg class="octicon octicon-git-commit" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Oct 5, 2013
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
    data-channel="repo:12876724:commit:4165c80a75110e69c94b455aba80a71f63193e64"
    data-url="/_render_node/MDY6Q29tbWl0MTI4NzY3MjQ6NDE2NWM4MGE3NTExMGU2OWM5NGI0NTVhYmE4MGE3MWY2MzE5M2U2NA==/commits/commits_list_item">
  
<div class="table-list-cell">
  <p class="commit-title h5 mb-1 text-gray-dark ">
      <a title="README url fix" class="message" data-pjax="true" href="/jaridmargolin/formatter.js/commit/4165c80a75110e69c94b455aba80a71f63193e64#diff-04c6e90faac2675aa89e2176d2eec7d8">README url fix</a>

  </p>

  <div class="commit-meta commit-author-section no-wrap d-flex flex-items-center mt-1">
    
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

    <div>
      
      <a href="/jaridmargolin/formatter.js/commits?author=jaridmargolin"
     class="commit-author tooltipped tooltipped-s user-mention"
     aria-label="View all commits by jaridmargolin">jaridmargolin</a>


  committed
  <relative-time datetime="2013-10-05T03:52:50Z">Oct 5, 2013</relative-time>

    </div>
      <div class="commit-indicator">
        
  <div class="commit-build-statuses">
      <a class="text-green tooltipped tooltipped-e"
         aria-label="Success: The Travis CI build passed"
         href="https://travis-ci.org/firstopinion/formatter.js/builds/12158626">
        <svg class="octicon octicon-check v-align-middle" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5z"/></svg>
      </a>
  </div>

      </div>
  </div>


</div>

<div class="commit-links-cell table-list-cell">

  


  <div class="commit-links-group BtnGroup">
    <clipboard-copy
        value="4165c80a75110e69c94b455aba80a71f63193e64"
        aria-label="Copy the full SHA"
        class="btn btn-outline BtnGroup-item tooltipped tooltipped-s"
        copied-label="Copied!">
      <svg class="octicon octicon-clippy" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg>
    </clipboard-copy>

    <a href="/jaridmargolin/formatter.js/commit/4165c80a75110e69c94b455aba80a71f63193e64#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
      4165c80
    </a>
  </div>
  <a href="/jaridmargolin/formatter.js/tree/4165c80a75110e69c94b455aba80a71f63193e64" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
</div>

</li>

            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
    data-channel="repo:12876724:commit:950d44695de7c9cc17c68bf89f7acc26795a5f0d"
    data-url="/_render_node/MDY6Q29tbWl0MTI4NzY3MjQ6OTUwZDQ0Njk1ZGU3YzljYzE3YzY4YmY4OWY3YWNjMjY3OTVhNWYwZA==/commits/commits_list_item">
  
<div class="table-list-cell">
  <p class="commit-title h5 mb-1 text-gray-dark ">
      <a title="Fix script. Update docs" class="message" data-pjax="true" href="/jaridmargolin/formatter.js/commit/950d44695de7c9cc17c68bf89f7acc26795a5f0d#diff-04c6e90faac2675aa89e2176d2eec7d8">Fix script. Update docs</a>

  </p>

  <div class="commit-meta commit-author-section no-wrap d-flex flex-items-center mt-1">
    
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

    <div>
      
      <a href="/jaridmargolin/formatter.js/commits?author=jaridmargolin"
     class="commit-author tooltipped tooltipped-s user-mention"
     aria-label="View all commits by jaridmargolin">jaridmargolin</a>


  committed
  <relative-time datetime="2013-10-05T02:26:27Z">Oct 5, 2013</relative-time>

    </div>
      <div class="commit-indicator">
        
  <div class="commit-build-statuses">
      <a class="text-green tooltipped tooltipped-e"
         aria-label="Success: The Travis CI build passed"
         href="https://travis-ci.org/firstopinion/formatter.js/builds/12157542">
        <svg class="octicon octicon-check v-align-middle" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5z"/></svg>
      </a>
  </div>

      </div>
  </div>


</div>

<div class="commit-links-cell table-list-cell">

  


  <div class="commit-links-group BtnGroup">
    <clipboard-copy
        value="950d44695de7c9cc17c68bf89f7acc26795a5f0d"
        aria-label="Copy the full SHA"
        class="btn btn-outline BtnGroup-item tooltipped tooltipped-s"
        copied-label="Copied!">
      <svg class="octicon octicon-clippy" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg>
    </clipboard-copy>

    <a href="/jaridmargolin/formatter.js/commit/950d44695de7c9cc17c68bf89f7acc26795a5f0d#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
      950d446
    </a>
  </div>
  <a href="/jaridmargolin/formatter.js/tree/950d44695de7c9cc17c68bf89f7acc26795a5f0d" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
</div>

</li>

        </ol>
        <div class="commit-group-title">
          <svg class="octicon octicon-git-commit" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Oct 4, 2013
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
    data-channel="repo:12876724:commit:bd3216bffb91aa7b229d905dec37bfa9b6d08f7f"
    data-url="/_render_node/MDY6Q29tbWl0MTI4NzY3MjQ6YmQzMjE2YmZmYjkxYWE3YjIyOWQ5MDVkZWMzN2JmYTliNmQwOGY3Zg==/commits/commits_list_item">
  
<div class="table-list-cell">
  <p class="commit-title h5 mb-1 text-gray-dark ">
      <a title="Update README.md to reflect current status" class="message" data-pjax="true" href="/jaridmargolin/formatter.js/commit/bd3216bffb91aa7b229d905dec37bfa9b6d08f7f#diff-04c6e90faac2675aa89e2176d2eec7d8">Update README.md to reflect current status</a>

  </p>

  <div class="commit-meta commit-author-section no-wrap d-flex flex-items-center mt-1">
    
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

    <div>
      
      <a href="/jaridmargolin/formatter.js/commits?author=jaridmargolin"
     class="commit-author tooltipped tooltipped-s user-mention"
     aria-label="View all commits by jaridmargolin">jaridmargolin</a>


  committed
  <relative-time datetime="2013-10-04T18:15:01Z">Oct 4, 2013</relative-time>

    </div>
      <div class="commit-indicator">
        
  <div class="commit-build-statuses">
      <a class="text-green tooltipped tooltipped-e"
         aria-label="Success: The Travis CI build passed"
         href="https://travis-ci.org/firstopinion/formatter.js/builds/12144616">
        <svg class="octicon octicon-check v-align-middle" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5z"/></svg>
      </a>
  </div>

      </div>
  </div>


</div>

<div class="commit-links-cell table-list-cell">

  


  <div class="commit-links-group BtnGroup">
    <clipboard-copy
        value="bd3216bffb91aa7b229d905dec37bfa9b6d08f7f"
        aria-label="Copy the full SHA"
        class="btn btn-outline BtnGroup-item tooltipped tooltipped-s"
        copied-label="Copied!">
      <svg class="octicon octicon-clippy" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg>
    </clipboard-copy>

    <a href="/jaridmargolin/formatter.js/commit/bd3216bffb91aa7b229d905dec37bfa9b6d08f7f#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
      bd3216b
    </a>
  </div>
  <a href="/jaridmargolin/formatter.js/tree/bd3216bffb91aa7b229d905dec37bfa9b6d08f7f" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
</div>

</li>

        </ol>
        <div class="commit-group-title">
          <svg class="octicon octicon-git-commit" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Sep 17, 2013
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
    data-channel="repo:12876724:commit:f85782cb5d5c05bdb17127e443f36f8743177039"
    data-url="/_render_node/MDY6Q29tbWl0MTI4NzY3MjQ6Zjg1NzgyY2I1ZDVjMDViZGIxNzEyN2U0NDNmMzZmODc0MzE3NzAzOQ==/commits/commits_list_item">
  
<div class="table-list-cell">
  <p class="commit-title h5 mb-1 text-gray-dark ">
      <a title="init checkin" class="message" data-pjax="true" href="/jaridmargolin/formatter.js/commit/f85782cb5d5c05bdb17127e443f36f8743177039#diff-04c6e90faac2675aa89e2176d2eec7d8">init checkin</a>

  </p>

  <div class="commit-meta commit-author-section no-wrap d-flex flex-items-center mt-1">
    
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

    <div>
      
      <a href="/jaridmargolin/formatter.js/commits?author=jaridmargolin"
     class="commit-author tooltipped tooltipped-s user-mention"
     aria-label="View all commits by jaridmargolin">jaridmargolin</a>


  committed
  <relative-time datetime="2013-09-17T16:44:22Z">Sep 17, 2013</relative-time>

    </div>
      <div class="commit-indicator">
        
  <div class="commit-build-statuses">
      <a class="text-red tooltipped tooltipped-e"
         aria-label="Failure: The Travis CI build failed"
         href="https://travis-ci.org/firstopinion/formatter.js/builds/11473086">
        <svg class="octicon octicon-x v-align-middle" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48z"/></svg>
      </a>
  </div>

      </div>
  </div>


</div>

<div class="commit-links-cell table-list-cell">

  


  <div class="commit-links-group BtnGroup">
    <clipboard-copy
        value="f85782cb5d5c05bdb17127e443f36f8743177039"
        aria-label="Copy the full SHA"
        class="btn btn-outline BtnGroup-item tooltipped tooltipped-s"
        copied-label="Copied!">
      <svg class="octicon octicon-clippy" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg>
    </clipboard-copy>

    <a href="/jaridmargolin/formatter.js/commit/f85782cb5d5c05bdb17127e443f36f8743177039#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
      f85782c
    </a>
  </div>
  <a href="/jaridmargolin/formatter.js/tree/f85782cb5d5c05bdb17127e443f36f8743177039" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
</div>

</li>

        </ol>
        <div class="commit-group-title">
          <svg class="octicon octicon-git-commit" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Sep 16, 2013
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
    data-channel="repo:12876724:commit:05c2e89d8405f99dd8f1becc74953af958730a21"
    data-url="/_render_node/MDY6Q29tbWl0MTI4NzY3MjQ6MDVjMmU4OWQ4NDA1Zjk5ZGQ4ZjFiZWNjNzQ5NTNhZjk1ODczMGEyMQ==/commits/commits_list_item">
  
<div class="table-list-cell">
  <p class="commit-title h5 mb-1 text-gray-dark ">
      <a title="Initial commit" class="message" data-pjax="true" href="/jaridmargolin/formatter.js/commit/05c2e89d8405f99dd8f1becc74953af958730a21#diff-04c6e90faac2675aa89e2176d2eec7d8">Initial commit</a>

  </p>

  <div class="commit-meta commit-author-section no-wrap d-flex flex-items-center mt-1">
    
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

    <div>
      
      <a href="/jaridmargolin/formatter.js/commits?author=jaridmargolin"
     class="commit-author tooltipped tooltipped-s user-mention"
     aria-label="View all commits by jaridmargolin">jaridmargolin</a>


  committed
  <relative-time datetime="2013-09-16T19:38:10Z">Sep 16, 2013</relative-time>

    </div>
  </div>


</div>

<div class="commit-links-cell table-list-cell">

  


  <div class="commit-links-group BtnGroup">
    <clipboard-copy
        value="05c2e89d8405f99dd8f1becc74953af958730a21"
        aria-label="Copy the full SHA"
        class="btn btn-outline BtnGroup-item tooltipped tooltipped-s"
        copied-label="Copied!">
      <svg class="octicon octicon-clippy" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg>
    </clipboard-copy>

    <a href="/jaridmargolin/formatter.js/commit/05c2e89d8405f99dd8f1becc74953af958730a21#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
      05c2e89
    </a>
  </div>
  <a href="/jaridmargolin/formatter.js/tree/05c2e89d8405f99dd8f1becc74953af958730a21" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
</div>

</li>

        </ol>
    </div>

    <div class="paginate-container" data-pjax data-html-cleaner-suppress-children>
      <div class="pagination"><span class="disabled">Newer</span><span class="disabled">Older</span></div>
    </div>

  </div>
  <div class="modal-backdrop js-touch-events"></div>
</div>

    </div>
  </div>

  </div>

      
<div class="footer container-lg px-3" role="contentinfo">
  <div class="position-relative d-flex flex-justify-between pt-6 pb-2 mt-6 f6 text-gray border-top border-gray-light ">
    <ul class="list-style-none d-flex flex-wrap ">
      <li class="mr-3">&copy; 2018 <span title="0.49516s from unicorn-265826001-wl08f">GitHub</span>, Inc.</li>
        <li class="mr-3"><a data-ga-click="Footer, go to terms, text:terms" href="https://github.com/site/terms">Terms</a></li>
        <li class="mr-3"><a data-ga-click="Footer, go to privacy, text:privacy" href="https://github.com/site/privacy">Privacy</a></li>
        <li class="mr-3"><a href="https://help.github.com/articles/github-security/" data-ga-click="Footer, go to security, text:security">Security</a></li>
        <li class="mr-3"><a href="https://status.github.com/" data-ga-click="Footer, go to status, text:status">Status</a></li>
        <li><a data-ga-click="Footer, go to help, text:help" href="https://help.github.com">Help</a></li>
    </ul>

    <a aria-label="Homepage" title="GitHub" class="footer-octicon" href="https://github.com">
      <svg height="24" class="octicon octicon-mark-github" viewBox="0 0 16 16" version="1.1" width="24" aria-hidden="true"><path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0 0 16 8c0-4.42-3.58-8-8-8z"/></svg>
</a>
   <ul class="list-style-none d-flex flex-wrap ">
        <li class="mr-3"><a data-ga-click="Footer, go to contact, text:contact" href="https://github.com/contact">Contact GitHub</a></li>
      <li class="mr-3"><a href="https://developer.github.com" data-ga-click="Footer, go to api, text:api">API</a></li>
      <li class="mr-3"><a href="https://training.github.com" data-ga-click="Footer, go to training, text:training">Training</a></li>
      <li class="mr-3"><a href="https://shop.github.com" data-ga-click="Footer, go to shop, text:shop">Shop</a></li>
        <li class="mr-3"><a data-ga-click="Footer, go to blog, text:blog" href="https://github.com/blog">Blog</a></li>
        <li><a data-ga-click="Footer, go to about, text:about" href="https://github.com/about">About</a></li>

    </ul>
  </div>
  <div class="d-flex flex-justify-center pb-6">
    <span class="f6 text-gray-light"></span>
  </div>
</div>



  <div id="ajax-error-message" class="ajax-error-message flash flash-error">
    <svg class="octicon octicon-alert" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M8.865 1.52c-.18-.31-.51-.5-.87-.5s-.69.19-.87.5L.275 13.5c-.18.31-.18.69 0 1 .19.31.52.5.87.5h13.7c.36 0 .69-.19.86-.5.17-.31.18-.69.01-1L8.865 1.52zM8.995 13h-2v-2h2v2zm0-3h-2V6h2v4z"/></svg>
    <button type="button" class="flash-close js-ajax-error-dismiss" aria-label="Dismiss error">
      <svg class="octicon octicon-x" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48z"/></svg>
    </button>
    You can't perform that action at this time.
  </div>


    <script crossorigin="anonymous" type="application/javascript" src="https://assets-cdn.github.com/assets/compat-680e7bbbbe79068a1cb3142329468a6f.js"></script>
    <script crossorigin="anonymous" type="application/javascript" src="https://assets-cdn.github.com/assets/frameworks-4a55ab3fcf005abef1e8b859483f3cce.js"></script>
    
    <script crossorigin="anonymous" async="async" type="application/javascript" src="https://assets-cdn.github.com/assets/github-2d728fdd9eab7e0c5ed0f7ee90304a01.js"></script>
    
    
    
    
  <div class="js-stale-session-flash stale-session-flash flash flash-warn flash-banner d-none">
    <svg class="octicon octicon-alert" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M8.865 1.52c-.18-.31-.51-.5-.87-.5s-.69.19-.87.5L.275 13.5c-.18.31-.18.69 0 1 .19.31.52.5.87.5h13.7c.36 0 .69-.19.86-.5.17-.31.18-.69.01-1L8.865 1.52zM8.995 13h-2v-2h2v2zm0-3h-2V6h2v4z"/></svg>
    <span class="signed-in-tab-flash">You signed in with another tab or window. <a href="">Reload</a> to refresh your session.</span>
    <span class="signed-out-tab-flash">You signed out in another tab or window. <a href="">Reload</a> to refresh your session.</span>
  </div>
  <div class="facebox" id="facebox" style="display:none;">
  <div class="facebox-popup">
    <div class="facebox-content" role="dialog" aria-labelledby="facebox-header" aria-describedby="facebox-description">
    </div>
    <button type="button" class="facebox-close js-facebox-close" aria-label="Close modal">
      <svg class="octicon octicon-x" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48z"/></svg>
    </button>
  </div>
</div>

  <div class="Popover js-hovercard-content position-absolute" style="display: none; outline: none;" tabindex="0">
  <div class="Popover-message Popover-message--bottom-left Popover-message--large Box box-shadow-large" style="width:360px;">
  </div>
</div>

<div id="hovercard-aria-description" class="sr-only">
  Press h to open a hovercard with more details.
</div>


  </body>
</html>

