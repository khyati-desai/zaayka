





<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
  <link rel="dns-prefetch" href="https://assets-cdn.github.com">
  <link rel="dns-prefetch" href="https://avatars0.githubusercontent.com">
  <link rel="dns-prefetch" href="https://avatars1.githubusercontent.com">
  <link rel="dns-prefetch" href="https://avatars2.githubusercontent.com">
  <link rel="dns-prefetch" href="https://avatars3.githubusercontent.com">
  <link rel="dns-prefetch" href="https://github-cloud.s3.amazonaws.com">
  <link rel="dns-prefetch" href="https://user-images.githubusercontent.com/">



  <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://assets-cdn.github.com/assets/frameworks-8f281eb0a8d2308ceb36e714ba3c3aec.css" />
  <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://assets-cdn.github.com/assets/github-cec46cb7e4a6c4b4c35e2dac77b2196d.css" />
  
  
  <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://assets-cdn.github.com/assets/site-83dc1f7ebc9c7461fe1eab799b56c4c4.css" />
  

  <meta name="viewport" content="width=device-width">
  
  <title>formatter.js/Gruntfile.js at master · jaridmargolin/formatter.js · GitHub</title>
    <meta name="description" content="GitHub is where people build software. More than 27 million people use GitHub to discover, fork, and contribute to over 80 million projects.">
  <link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="GitHub">
  <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
  <meta property="fb:app_id" content="1401488693436528">

    
    <meta property="og:image" content="https://avatars1.githubusercontent.com/u/933685?s=400&amp;v=4" /><meta property="og:site_name" content="GitHub" /><meta property="og:type" content="object" /><meta property="og:title" content="jaridmargolin/formatter.js" /><meta property="og:url" content="https://github.com/jaridmargolin/formatter.js" /><meta property="og:description" content="Format html inputs to match a specified pattern. Contribute to formatter.js development by creating an account on GitHub." />

  <link rel="assets" href="https://assets-cdn.github.com/">
  
  <meta name="pjax-timeout" content="1000">
  
  <meta name="request-id" content="725D:10FA:16D4F68:2D0E1E5:5ACB6446" data-pjax-transient>


  

  <meta name="selected-link" value="repo_source" data-pjax-transient>

    <meta name="google-site-verification" content="KT5gs8h0wvaagLKAVWq8bbeNwnZZK1r1XQysX3xurLU">
  <meta name="google-site-verification" content="ZzhVyEFwb7w3e0-uOTltm8Jsck2F5StVihD0exw2fsA">
  <meta name="google-site-verification" content="GXs5KoUUkNCoaAZn7wPN-t01Pywp9M3sEjnt_3_ZWPc">
    <meta name="google-analytics" content="UA-3769691-2">

<meta name="octolytics-host" content="collector.githubapp.com" /><meta name="octolytics-app-id" content="github" /><meta name="octolytics-event-url" content="https://collector.githubapp.com/github-external/browser_event" /><meta name="octolytics-dimension-request_id" content="725D:10FA:16D4F68:2D0E1E5:5ACB6446" /><meta name="octolytics-dimension-region_edge" content="iad" /><meta name="octolytics-dimension-region_render" content="iad" />
<meta name="hydro-events-url" content="https://github.com/hydro_browser_events" />
<meta name="analytics-location" content="/&lt;user-name&gt;/&lt;repo-name&gt;/blob/blame" data-pjax-transient="true" />




  <meta class="js-ga-set" name="dimension1" content="Logged Out">


  

      <meta name="hostname" content="github.com">
    <meta name="user-login" content="">

      <meta name="expected-hostname" content="github.com">
    <meta name="js-proxy-site-detection-payload" content="NjA0OTA0NWIzNDBmYzgyYWFlNDMxNjM3ZDVhMGUwMDNmZDFmYmEwZGI5M2UwZDdkMzFkYTNkOWI5ZTczZGE5MHx7InJlbW90ZV9hZGRyZXNzIjoiMTE2LjcyLjUyLjIzMiIsInJlcXVlc3RfaWQiOiI3MjVEOjEwRkE6MTZENEY2ODoyRDBFMUU1OjVBQ0I2NDQ2IiwidGltZXN0YW1wIjoxNTIzMjc4OTE5LCJob3N0IjoiZ2l0aHViLmNvbSJ9">

    <meta name="enabled-features" content="UNIVERSE_BANNER,FREE_TRIALS,MARKETPLACE_INSIGHTS,MARKETPLACE_SELF_SERVE,MARKETPLACE_INSIGHTS_CONVERSION_PERCENTAGES">

  <meta name="html-safe-nonce" content="c93ed10e39cc785bf529e2db8313369c9d932977">

  <meta http-equiv="x-pjax-version" content="4c09b81681961f2efccc0240274e1d51">
  

      <link href="https://github.com/jaridmargolin/formatter.js/commits/master.atom" rel="alternate" title="Recent Commits to formatter.js:master" type="application/atom+xml">

  <meta name="description" content="Format html inputs to match a specified pattern. Contribute to formatter.js development by creating an account on GitHub.">
  <meta name="go-import" content="github.com/jaridmargolin/formatter.js git https://github.com/jaridmargolin/formatter.js.git">

  <meta name="octolytics-dimension-user_id" content="933685" /><meta name="octolytics-dimension-user_login" content="jaridmargolin" /><meta name="octolytics-dimension-repository_id" content="12876724" /><meta name="octolytics-dimension-repository_nwo" content="jaridmargolin/formatter.js" /><meta name="octolytics-dimension-repository_public" content="true" /><meta name="octolytics-dimension-repository_is_fork" content="false" /><meta name="octolytics-dimension-repository_network_root_id" content="12876724" /><meta name="octolytics-dimension-repository_network_root_nwo" content="jaridmargolin/formatter.js" /><meta name="octolytics-dimension-repository_explore_github_marketplace_ci_cta_shown" content="false" />




  <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">

  <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">

  <link rel="mask-icon" href="https://assets-cdn.github.com/pinned-octocat.svg" color="#000000">
  <link rel="icon" type="image/x-icon" class="js-site-favicon" href="https://assets-cdn.github.com/favicon.ico">

<meta name="theme-color" content="#1e2327">



<link rel="manifest" href="/manifest.json" crossOrigin="use-credentials">

  </head>

  <body class="logged-out env-production full-width">
    

  <div class="position-relative js-header-wrapper ">
    <a href="#start-of-content" tabindex="1" class="px-2 py-4bg-blue text-white show-on-focus js-skip-to-content">Skip to content</a>
    <div id="js-pjax-loader-bar" class="pjax-loader-bar"><div class="progress"></div></div>

    
    
    



        <header class="Header header-logged-out  position-relative f4 py-3" role="banner">
  <div class="container-lg d-flex px-3">
    <div class="d-flex flex-justify-between flex-items-center">
      <a class="header-logo-invertocat my-0" href="https://github.com/" aria-label="Homepage" data-ga-click="(Logged out) Header, go to homepage, icon:logo-wordmark">
        <svg height="32" class="octicon octicon-mark-github" viewBox="0 0 16 16" version="1.1" width="32" aria-hidden="true"><path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0 0 16 8c0-4.42-3.58-8-8-8z"/></svg>
      </a>

    </div>

    <div class="HeaderMenu HeaderMenu--bright d-flex flex-justify-between flex-auto">
        <nav class="mt-0">
          <ul class="d-flex list-style-none">
              <li class="ml-2">
                <a class="js-selected-navigation-item HeaderNavlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:features" data-selected-links="/features /features/project-management /features/code-review /features/project-management /features/integrations /features" href="/features">
                  Features
</a>              </li>
              <li class="ml-4">
                <a class="js-selected-navigation-item HeaderNavlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:business" data-selected-links="/business /business/security /business/customers /business" href="/business">
                  Business
</a>              </li>

              <li class="ml-4">
                <a class="js-selected-navigation-item HeaderNavlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:explore" data-selected-links="/explore /trending /trending/developers /integrations /integrations/feature/code /integrations/feature/collaborate /integrations/feature/ship showcases showcases_search showcases_landing /explore" href="/explore">
                  Explore
</a>              </li>

              <li class="ml-4">
                    <a class="js-selected-navigation-item HeaderNavlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:marketplace" data-selected-links=" /marketplace" href="/marketplace">
                      Marketplace
</a>              </li>
              <li class="ml-4">
                <a class="js-selected-navigation-item HeaderNavlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:pricing" data-selected-links="/pricing /pricing/developer /pricing/team /pricing/business-hosted /pricing/business-enterprise /pricing" href="/pricing">
                  Pricing
</a>              </li>
          </ul>
        </nav>

      <div class="d-flex">
          <div class="d-lg-flex flex-items-center mr-3">
            <div class="header-search scoped-search site-scoped-search js-site-search" role="search">
  <!-- '"` --><!-- </textarea></xmp> --></option></form><form class="js-site-search-form" data-scoped-search-url="/jaridmargolin/formatter.js/search" data-unscoped-search-url="/search" action="/jaridmargolin/formatter.js/search" accept-charset="UTF-8" method="get"><input name="utf8" type="hidden" value="&#x2713;" />
    <label class="form-control header-search-wrapper  js-chromeless-input-container">
        <a class="header-search-scope no-underline" href="/jaridmargolin/formatter.js/blame/master/Gruntfile.js">This repository</a>
      <input type="text"
        class="form-control header-search-input  js-site-search-focus js-site-search-field is-clearable"
        data-hotkey="s,/"
        name="q"
        value=""
        placeholder="Search"
        aria-label="Search this repository"
        data-unscoped-placeholder="Search GitHub"
        data-scoped-placeholder="Search"
        autocapitalize="off"
        >
        <input type="hidden" class="js-site-search-type-field" name="type" >
    </label>
</form></div>

          </div>

        <span class="d-inline-block">
            <div class="HeaderNavlink px-0 py-2 m-0">
              <a class="text-bold text-white no-underline" href="/login?return_to=%2Fjaridmargolin%2Fformatter.js%2Fblame%2Fmaster%2FGruntfile.js" data-ga-click="(Logged out) Header, clicked Sign in, text:sign-in">Sign in</a>
                <span class="text-gray">or</span>
                <a class="text-bold text-white no-underline" href="/join?source=header-repo" data-ga-click="(Logged out) Header, clicked Sign up, text:sign-up">Sign up</a>
            </div>
        </span>
      </div>
    </div>
  </div>
</header>

  </div>

  <div id="start-of-content" class="show-on-focus"></div>

    <div id="js-flash-container">
</div>



  <div role="main" class="application-main ">
        <div itemscope itemtype="http://schema.org/SoftwareSourceCode" class="">
    <div id="js-repo-pjax-container" data-pjax-container >
      






  <div class="pagehead repohead instapaper_ignore readability-menu experiment-repo-nav  ">
    <div class="repohead-details-container clearfix container">

      <ul class="pagehead-actions">
  <li>
      <a href="/login?return_to=%2Fjaridmargolin%2Fformatter.js"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to watch a repository" rel="nofollow">
    <svg class="octicon octicon-eye" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M8.06 2C3 2 0 8 0 8s3 6 8.06 6C13 14 16 8 16 8s-3-6-7.94-6zM8 12c-2.2 0-4-1.78-4-4 0-2.2 1.8-4 4-4 2.22 0 4 1.8 4 4 0 2.22-1.78 4-4 4zm2-4c0 1.11-.89 2-2 2-1.11 0-2-.89-2-2 0-1.11.89-2 2-2 1.11 0 2 .89 2 2z"/></svg>
    Watch
  </a>
  <a class="social-count" href="/jaridmargolin/formatter.js/watchers"
     aria-label="83 users are watching this repository">
    83
  </a>

  </li>

  <li>
      <a href="/login?return_to=%2Fjaridmargolin%2Fformatter.js"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to star a repository" rel="nofollow">
    <svg class="octicon octicon-star" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M14 6l-4.9-.64L7 1 4.9 5.36 0 6l3.6 3.26L2.67 14 7 11.67 11.33 14l-.93-4.74z"/></svg>
    Star
  </a>

    <a class="social-count js-social-count" href="/jaridmargolin/formatter.js/stargazers"
      aria-label="2541 users starred this repository">
      2,541
    </a>

  </li>

  <li>
      <a href="/login?return_to=%2Fjaridmargolin%2Fformatter.js"
        class="btn btn-sm btn-with-count tooltipped tooltipped-n"
        aria-label="You must be signed in to fork a repository" rel="nofollow">
        <svg class="octicon octicon-repo-forked" viewBox="0 0 10 16" version="1.1" width="10" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M8 1a1.993 1.993 0 0 0-1 3.72V6L5 8 3 6V4.72A1.993 1.993 0 0 0 2 1a1.993 1.993 0 0 0-1 3.72V6.5l3 3v1.78A1.993 1.993 0 0 0 5 15a1.993 1.993 0 0 0 1-3.72V9.5l3-3V4.72A1.993 1.993 0 0 0 8 1zM2 4.2C1.34 4.2.8 3.65.8 3c0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zm3 10c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zm3-10c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2z"/></svg>
        Fork
      </a>

    <a href="/jaridmargolin/formatter.js/network" class="social-count"
       aria-label="250 users forked this repository">
      250
    </a>
  </li>
</ul>

      <h1 class="public ">
  <svg class="octicon octicon-repo" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M4 9H3V8h1v1zm0-3H3v1h1V6zm0-2H3v1h1V4zm0-2H3v1h1V2zm8-1v12c0 .55-.45 1-1 1H6v2l-1.5-1.5L3 16v-2H1c-.55 0-1-.45-1-1V1c0-.55.45-1 1-1h10c.55 0 1 .45 1 1zm-1 10H1v2h2v-1h3v1h5v-2zm0-10H2v9h9V1z"/></svg>
  <span class="author" itemprop="author"><a class="url fn" rel="author" href="/jaridmargolin">jaridmargolin</a></span><!--
--><span class="path-divider">/</span><!--
--><strong itemprop="name"><a data-pjax="#js-repo-pjax-container" href="/jaridmargolin/formatter.js">formatter.js</a></strong>

</h1>

    </div>
    
<nav class="reponav js-repo-nav js-sidenav-container-pjax container"
     itemscope
     itemtype="http://schema.org/BreadcrumbList"
     role="navigation"
     data-pjax="#js-repo-pjax-container">

  <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
    <a class="js-selected-navigation-item selected reponav-item" itemprop="url" data-hotkey="g c" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches repo_packages /jaridmargolin/formatter.js" href="/jaridmargolin/formatter.js">
      <svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg>
      <span itemprop="name">Code</span>
      <meta itemprop="position" content="1">
</a>  </span>

    <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
      <a itemprop="url" data-hotkey="g i" class="js-selected-navigation-item reponav-item" data-selected-links="repo_issues repo_labels repo_milestones /jaridmargolin/formatter.js/issues" href="/jaridmargolin/formatter.js/issues">
        <svg class="octicon octicon-issue-opened" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7 2.3c3.14 0 5.7 2.56 5.7 5.7s-2.56 5.7-5.7 5.7A5.71 5.71 0 0 1 1.3 8c0-3.14 2.56-5.7 5.7-5.7zM7 1C3.14 1 0 4.14 0 8s3.14 7 7 7 7-3.14 7-7-3.14-7-7-7zm1 3H6v5h2V4zm0 6H6v2h2v-2z"/></svg>
        <span itemprop="name">Issues</span>
        <span class="Counter">38</span>
        <meta itemprop="position" content="2">
</a>    </span>

  <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
    <a data-hotkey="g p" itemprop="url" class="js-selected-navigation-item reponav-item" data-selected-links="repo_pulls checks /jaridmargolin/formatter.js/pulls" href="/jaridmargolin/formatter.js/pulls">
      <svg class="octicon octicon-git-pull-request" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M11 11.28V5c-.03-.78-.34-1.47-.94-2.06C9.46 2.35 8.78 2.03 8 2H7V0L4 3l3 3V4h1c.27.02.48.11.69.31.21.2.3.42.31.69v6.28A1.993 1.993 0 0 0 10 15a1.993 1.993 0 0 0 1-3.72zm-1 2.92c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zM4 3c0-1.11-.89-2-2-2a1.993 1.993 0 0 0-1 3.72v6.56A1.993 1.993 0 0 0 2 15a1.993 1.993 0 0 0 1-3.72V4.72c.59-.34 1-.98 1-1.72zm-.8 10c0 .66-.55 1.2-1.2 1.2-.65 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2zM2 4.2C1.34 4.2.8 3.65.8 3c0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2z"/></svg>
      <span itemprop="name">Pull requests</span>
      <span class="Counter">14</span>
      <meta itemprop="position" content="3">
</a>  </span>

    <a data-hotkey="g b" class="js-selected-navigation-item reponav-item" data-selected-links="repo_projects new_repo_project repo_project /jaridmargolin/formatter.js/projects" href="/jaridmargolin/formatter.js/projects">
      <svg class="octicon octicon-project" viewBox="0 0 15 16" version="1.1" width="15" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M10 12h3V2h-3v10zm-4-2h3V2H6v8zm-4 4h3V2H2v12zm-1 1h13V1H1v14zM14 0H1a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h13a1 1 0 0 0 1-1V1a1 1 0 0 0-1-1z"/></svg>
      Projects
      <span class="Counter" >0</span>
</a>


  <a class="js-selected-navigation-item reponav-item" data-selected-links="repo_graphs repo_contributors dependency_graph pulse /jaridmargolin/formatter.js/pulse" href="/jaridmargolin/formatter.js/pulse">
    <svg class="octicon octicon-graph" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M16 14v1H0V0h1v14h15zM5 13H3V8h2v5zm4 0H7V3h2v10zm4 0h-2V6h2v7z"/></svg>
    Insights
</a>

</nav>


  </div>

<div class="container new-discussion-timeline experiment-repo-nav  ">
  <div class="repository-content ">

    

  <div class="wants-full-width-container"></div>

  <a class="d-none js-permalink-shortcut" data-hotkey="y" href="/jaridmargolin/formatter.js/blame/51c068bed4e78ba5db7f44911f7ae8ef259f692f/Gruntfile.js">Permalink</a>

  <div class="breadcrumb css-truncate blame-breadcrumb">
    <span id="blob-path" class="css-truncate-target"><span class="repo-root js-repo-root"><span class="js-path-segment"><a data-pjax="true" href="/jaridmargolin/formatter.js"><span>formatter.js</span></a></span></span><span class="separator">/</span><strong class="final-path">Gruntfile.js</strong></span>
    <clipboard-copy
        for="blob-path"
        aria-label="Copy file path to clipboard"
        class="btn btn-sm tooltipped tooltipped-s"
        copied-label="Copied!">
      <svg class="octicon octicon-clippy" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg>
    </clipboard-copy>
  </div>

  <div class="line-age-legend float-right mt-n4 f6">
    <span>Newer</span>
    <ol class="d-inline-block mx-1 list-style-none">
        <li class="heat d-inline-block" data-heat="1"></li>
        <li class="heat d-inline-block" data-heat="2"></li>
        <li class="heat d-inline-block" data-heat="3"></li>
        <li class="heat d-inline-block" data-heat="4"></li>
        <li class="heat d-inline-block" data-heat="5"></li>
        <li class="heat d-inline-block" data-heat="6"></li>
        <li class="heat d-inline-block" data-heat="7"></li>
        <li class="heat d-inline-block" data-heat="8"></li>
        <li class="heat d-inline-block" data-heat="9"></li>
        <li class="heat d-inline-block" data-heat="10"></li>
    </ol>
    <span>Older</span>
  </div>

  <div class="file">
    <div class="file-header">
      <div class="file-actions">
        <div class="BtnGroup">
          <a id="raw-url" class="btn btn-sm BtnGroup-item" href="/jaridmargolin/formatter.js/raw/master/Gruntfile.js">Raw</a>
          <a class="btn btn-sm js-update-url-with-hash BtnGroup-item" href="/jaridmargolin/formatter.js/blob/master/Gruntfile.js">Normal view</a>
          <a rel="nofollow" class="btn btn-sm BtnGroup-item" href="/jaridmargolin/formatter.js/commits/master/Gruntfile.js">History</a>
        </div>
      </div>

  

      <div class="file-info">
        <svg class="octicon octicon-file" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M6 5H2V4h4v1zM2 8h7V7H2v1zm0 2h7V9H2v1zm0 2h7v-1H2v1zm10-7.5V14c0 .55-.45 1-1 1H1c-.55 0-1-.45-1-1V2c0-.55.45-1 1-1h7.5L12 4.5zM11 5L8 2H1v12h10V5z"/></svg>
        <span class="file-mode" title="File Mode">100644</span>
        <span class="file-info-divider"></span>
          327 lines (266 sloc)
          <span class="file-info-divider"></span>
        7.83 KB
      </div>
    </div>

    <div class="blob-wrapper">
      <div class="blame-container  highlight data js-file-line-container tab-size" data-tab-size="8">

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="10">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a title="Refactor to use AMD. Overhaul build process." data-pjax="true" class="message f6 text-gray-dark" href="/jaridmargolin/formatter.js/commit/f90acacb7c7d2c0bef27fc079699305b8f94431e">Refactor to use AMD. Overhaul build process.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="10"><time-ago datetime="2014-05-09T00:07:22Z">May 9, 2014</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/jaridmargolin/formatter.js/blame/4b94b66e1f4246df3875979dc6a460aa1e9d9d0e/Gruntfile.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L1">1</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC1"><span class="pl-c"><span class="pl-c">/*</span>!</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L2">2</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC2"><span class="pl-c"> * Gruntfile.js</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L3">3</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC3"><span class="pl-c"> * </span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L4">4</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC4"><span class="pl-c"> * Copyright (c) 2014</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L5">5</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC5"><span class="pl-c"> <span class="pl-c">*/</span></span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L6">6</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC6">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L7">7</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC7">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L8">8</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC8"><span class="pl-c1">module</span>.<span class="pl-en">exports</span> <span class="pl-k">=</span> <span class="pl-k">function</span> (<span class="pl-smi">grunt</span>) {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L9">9</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC9">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L10">10</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC10">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L11">11</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC11"><span class="pl-c"><span class="pl-c">//</span> Load tasks</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L12">12</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC12"><span class="pl-c1">require</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>matchdep<span class="pl-pds">&#39;</span></span>).<span class="pl-en">filterDev</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>grunt-*<span class="pl-pds">&#39;</span></span>).<span class="pl-c1">forEach</span>(<span class="pl-smi">grunt</span>.<span class="pl-smi">loadNpmTasks</span>);</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L13">13</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC13">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L14">14</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC14">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L15">15</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC15"><span class="pl-c"><span class="pl-c">//</span> Browsers</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L16">16</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC16"><span class="pl-k">var</span> browsers <span class="pl-k">=</span> [</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L17">17</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC17">  <span class="pl-c"><span class="pl-c">//</span> Latest Versions</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L18">18</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC18">  { browserName<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>firefox<span class="pl-pds">&#39;</span></span>, platform<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>WIN8<span class="pl-pds">&#39;</span></span> },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L19">19</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC19">  { browserName<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>chrome<span class="pl-pds">&#39;</span></span>, platform<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>WIN8<span class="pl-pds">&#39;</span></span> },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L20">20</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC20">  { browserName<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>opera<span class="pl-pds">&#39;</span></span>, platform<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>WIN7<span class="pl-pds">&#39;</span></span> },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L21">21</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC21">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L22">22</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC22">  <span class="pl-c"><span class="pl-c">//</span> Internet Explorer</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L23">23</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC23">  { browserName<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>internet explorer<span class="pl-pds">&#39;</span></span>, platform<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>WIN8<span class="pl-pds">&#39;</span></span>, version<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>10<span class="pl-pds">&#39;</span></span> },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L24">24</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC24">  { browserName<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>internet explorer<span class="pl-pds">&#39;</span></span>, platform<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>VISTA<span class="pl-pds">&#39;</span></span>, version<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>9<span class="pl-pds">&#39;</span></span> },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L25">25</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC25">  { browserName<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>internet explorer<span class="pl-pds">&#39;</span></span>, platform<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>XP<span class="pl-pds">&#39;</span></span>, version<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>8<span class="pl-pds">&#39;</span></span> }</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L26">26</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC26">];</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L27">27</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC27">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L28">28</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC28">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L29">29</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC29"><span class="pl-c"><span class="pl-c">//</span> Config</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L30">30</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC30"><span class="pl-smi">grunt</span>.<span class="pl-en">initConfig</span>({</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L31">31</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC31">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L32">32</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC32">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L33">33</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC33">  <span class="pl-c"><span class="pl-c">//</span> PKG CONFIG</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L34">34</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC34">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L35">35</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC35">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L36">36</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC36">  <span class="pl-s"><span class="pl-pds">&#39;</span>pkg<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> <span class="pl-smi">grunt</span>.<span class="pl-smi">file</span>.<span class="pl-en">readJSON</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>package.json<span class="pl-pds">&#39;</span></span>),</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L37">37</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC37">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L38">38</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC38">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L39">39</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC39">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L40">40</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC40">  <span class="pl-c"><span class="pl-c">//</span> JSHINT</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L41">41</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC41">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L42">42</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC42">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L43">43</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC43">  <span class="pl-s"><span class="pl-pds">&#39;</span>jshint<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L44">44</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC44">    src<span class="pl-k">:</span> [</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L45">45</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC45">      <span class="pl-s"><span class="pl-pds">&#39;</span>Gruntfile.js<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L46">46</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC46">      <span class="pl-s"><span class="pl-pds">&#39;</span>src/**/*.js<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L47">47</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC47">      <span class="pl-s"><span class="pl-pds">&#39;</span>test/**/*.js<span class="pl-pds">&#39;</span></span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L48">48</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC48">    ],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L49">49</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC49">    build<span class="pl-k">:</span> [</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L50">50</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC50">      <span class="pl-s"><span class="pl-pds">&#39;</span>dist/**/*.js<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L51">51</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC51">      <span class="pl-s"><span class="pl-pds">&#39;</span>!dist/**/*.min.js<span class="pl-pds">&#39;</span></span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L52">52</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC52">    ],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L53">53</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC53">    options<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L54">54</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC54">      jshintrc<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>.jshintrc<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L55">55</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC55">      force<span class="pl-k">:</span> <span class="pl-c1">true</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L56">56</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC56">    }</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L57">57</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC57">  },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L58">58</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC58">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L59">59</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC59">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L60">60</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC60">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L61">61</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC61">  <span class="pl-c"><span class="pl-c">//</span> CLEAN (EMPTY DIRECTORY)</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L62">62</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC62">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L63">63</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC63">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L64">64</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC64">  <span class="pl-s"><span class="pl-pds">&#39;</span>clean<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L65">65</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC65">    dist<span class="pl-k">:</span> [</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L66">66</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC66">      <span class="pl-s"><span class="pl-pds">&#39;</span>dist<span class="pl-pds">&#39;</span></span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L67">67</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC67">    ],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L68">68</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC68">    docs<span class="pl-k">:</span> [</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L69">69</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC69">      <span class="pl-s"><span class="pl-pds">&#39;</span>docs/javascripts/*formatter.js<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L70">70</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC70">      <span class="pl-s"><span class="pl-pds">&#39;</span>docs/javascripts/*formatter.min.js<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L71">71</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC71">      <span class="pl-s"><span class="pl-pds">&#39;</span>docs/index.md<span class="pl-pds">&#39;</span></span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L72">72</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC72">    ]</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L73">73</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC73">  },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L74">74</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC74">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L75">75</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC75">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L76">76</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC76">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L77">77</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC77">  <span class="pl-c"><span class="pl-c">//</span> REQUIREJS BUILD</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L78">78</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC78">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L79">79</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC79">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L80">80</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC80">  <span class="pl-s"><span class="pl-pds">&#39;</span>requirejs<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L81">81</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC81">    compile<span class="pl-k">:</span> {</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="10">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a title="v0.0.2" data-pjax="true" class="message f6 text-gray-dark" href="/jaridmargolin/formatter.js/commit/46b53256b614c877cb51cadade3ca4d8bb5e7022">v0.0.2</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="10"><time-ago datetime="2013-10-21T21:20:19Z">Oct 21, 2013</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L82">82</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC82">      options<span class="pl-k">:</span> {</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="10">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a title="Refactor to use AMD. Overhaul build process." data-pjax="true" class="message f6 text-gray-dark" href="/jaridmargolin/formatter.js/commit/f90acacb7c7d2c0bef27fc079699305b8f94431e">Refactor to use AMD. Overhaul build process.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="10"><time-ago datetime="2014-05-09T00:07:22Z">May 9, 2014</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/jaridmargolin/formatter.js/blame/4b94b66e1f4246df3875979dc6a460aa1e9d9d0e/Gruntfile.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L83">83</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC83">        name<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>formatter<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L84">84</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC84">        baseUrl<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>src<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L85">85</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC85">        out<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>dist/formatter.js<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L86">86</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC86">        optimize<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>none<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L87">87</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC87">        skipModuleInsertion<span class="pl-k">:</span> <span class="pl-c1">true</span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L88">88</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC88">        <span class="pl-en">onBuildWrite</span><span class="pl-k">:</span> <span class="pl-k">function</span>(<span class="pl-smi">name</span>, <span class="pl-smi">path</span>, <span class="pl-smi">contents</span>) {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L89">89</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC89">          <span class="pl-k">return</span> <span class="pl-c1">require</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>amdclean<span class="pl-pds">&#39;</span></span>).<span class="pl-en">clean</span>({</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L90">90</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC90">            code<span class="pl-k">:</span> contents,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L91">91</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC91">            prefixMode<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>camelCase<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L92">92</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC92">            escodegen<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L93">93</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC93">              format<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L94">94</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC94">                indent<span class="pl-k">:</span> { style<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>  <span class="pl-pds">&#39;</span></span> }</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L95">95</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC95">              }</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L96">96</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC96">            }</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L97">97</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC97">          });</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L98">98</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC98">        }</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="10">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a title="v0.0.2" data-pjax="true" class="message f6 text-gray-dark" href="/jaridmargolin/formatter.js/commit/46b53256b614c877cb51cadade3ca4d8bb5e7022">v0.0.2</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="10"><time-ago datetime="2013-10-21T21:20:19Z">Oct 21, 2013</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L99">99</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC99">      }</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="10">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a title="Refactor to use AMD. Overhaul build process." data-pjax="true" class="message f6 text-gray-dark" href="/jaridmargolin/formatter.js/commit/f90acacb7c7d2c0bef27fc079699305b8f94431e">Refactor to use AMD. Overhaul build process.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="10"><time-ago datetime="2014-05-09T00:07:22Z">May 9, 2014</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/jaridmargolin/formatter.js/blame/4b94b66e1f4246df3875979dc6a460aa1e9d9d0e/Gruntfile.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L100">100</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC100">    }</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L101">101</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC101">  },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L102">102</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC102">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L103">103</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC103">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L104">104</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC104">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L105">105</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC105">  <span class="pl-c"><span class="pl-c">//</span> UMD WRAP</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L106">106</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC106">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L107">107</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC107">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L108">108</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC108">  <span class="pl-s"><span class="pl-pds">&#39;</span>umd<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L109">109</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC109">    jquery<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L110">110</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC110">      src<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>dist/formatter.js<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L111">111</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC111">      dest<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>dist/jquery.formatter.js<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L112">112</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC112">      template<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>src/tmpls/jquery.hbs<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L113">113</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC113">      deps<span class="pl-k">:</span> { <span class="pl-s"><span class="pl-pds">&#39;</span>default<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>jQuery<span class="pl-pds">&#39;</span></span>] }</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L114">114</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC114">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L115">115</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC115">    umd<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L116">116</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC116">      src<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>dist/formatter.js<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L117">117</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC117">      objectToExport<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>formatter<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L118">118</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC118">      globalAlias<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>Formatter<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L119">119</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC119">      template<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>src/tmpls/umd.hbs<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L120">120</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC120">      dest<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>dist/formatter.js<span class="pl-pds">&#39;</span></span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L121">121</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC121">    }</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L122">122</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC122">  },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L123">123</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC123">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L124">124</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC124">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L125">125</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC125">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L126">126</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC126">  <span class="pl-c"><span class="pl-c">//</span> ADD BANNER</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L127">127</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC127">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L128">128</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC128">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L129">129</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC129">  <span class="pl-s"><span class="pl-pds">&#39;</span>concat<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L130">130</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC130">    options<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L131">131</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC131">      banner<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>/*!<span class="pl-cce">\n</span><span class="pl-pds">&#39;</span></span> <span class="pl-k">+</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L132">132</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC132">        <span class="pl-s"><span class="pl-pds">&#39;</span> * v&lt;%= pkg.version %&gt;<span class="pl-cce">\n</span><span class="pl-pds">&#39;</span></span> <span class="pl-k">+</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L133">133</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC133">        <span class="pl-s"><span class="pl-pds">&#39;</span> * Copyright (c) 2014 First Opinion<span class="pl-cce">\n</span><span class="pl-pds">&#39;</span></span> <span class="pl-k">+</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L134">134</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC134">        <span class="pl-s"><span class="pl-pds">&#39;</span> * formatter.js is open sourced under the MIT license.<span class="pl-cce">\n</span><span class="pl-pds">&#39;</span></span> <span class="pl-k">+</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L135">135</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC135">        <span class="pl-s"><span class="pl-pds">&#39;</span> *<span class="pl-cce">\n</span><span class="pl-pds">&#39;</span></span> <span class="pl-k">+</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L136">136</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC136">        <span class="pl-s"><span class="pl-pds">&#39;</span> * thanks to digitalBush/jquery.maskedinput for some of the trickier<span class="pl-cce">\n</span><span class="pl-pds">&#39;</span></span> <span class="pl-k">+</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L137">137</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC137">        <span class="pl-s"><span class="pl-pds">&#39;</span> * keycode handling<span class="pl-cce">\n</span><span class="pl-pds">&#39;</span></span> <span class="pl-k">+</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L138">138</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC138">        <span class="pl-s"><span class="pl-pds">&#39;</span> */ <span class="pl-cce">\n\n</span><span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L139">139</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC139">      stripBanners<span class="pl-k">:</span> <span class="pl-c1">true</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L140">140</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC140">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L141">141</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC141">    umd<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L142">142</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC142">      src<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>dist/formatter.js<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L143">143</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC143">      dest<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>dist/formatter.js<span class="pl-pds">&#39;</span></span></div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="10">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a title="v0.0.2" data-pjax="true" class="message f6 text-gray-dark" href="/jaridmargolin/formatter.js/commit/46b53256b614c877cb51cadade3ca4d8bb5e7022">v0.0.2</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="10"><time-ago datetime="2013-10-21T21:20:19Z">Oct 21, 2013</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L144">144</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC144">    },</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="10">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a title="Refactor to use AMD. Overhaul build process." data-pjax="true" class="message f6 text-gray-dark" href="/jaridmargolin/formatter.js/commit/f90acacb7c7d2c0bef27fc079699305b8f94431e">Refactor to use AMD. Overhaul build process.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="10"><time-ago datetime="2014-05-09T00:07:22Z">May 9, 2014</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/jaridmargolin/formatter.js/blame/4b94b66e1f4246df3875979dc6a460aa1e9d9d0e/Gruntfile.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L145">145</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC145">    jquery<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L146">146</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC146">      src<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>dist/jquery.formatter.js<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L147">147</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC147">      dest<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>dist/jquery.formatter.js<span class="pl-pds">&#39;</span></span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L148">148</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC148">    }</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L149">149</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC149">  },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L150">150</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC150">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L151">151</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC151">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L152">152</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC152">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L153">153</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC153">  <span class="pl-c"><span class="pl-c">//</span> MINIFY JS</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L154">154</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC154">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L155">155</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC155">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L156">156</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC156">  <span class="pl-s"><span class="pl-pds">&#39;</span>uglify<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L157">157</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC157">    umd<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L158">158</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC158">      src<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>dist/formatter.js<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L159">159</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC159">      dest<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>dist/formatter.min.js<span class="pl-pds">&#39;</span></span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L160">160</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC160">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L161">161</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC161">    jquery<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L162">162</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC162">      src<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>dist/jquery.formatter.js<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L163">163</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC163">      dest<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>dist/jquery.formatter.min.js<span class="pl-pds">&#39;</span></span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L164">164</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC164">    }</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L165">165</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC165">  },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L166">166</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC166">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L167">167</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC167">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L168">168</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC168">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L169">169</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC169">  <span class="pl-c"><span class="pl-c">//</span> CREATE COMMONJS VERSION IN DIST</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L170">170</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC170">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L171">171</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC171">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L172">172</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC172">  <span class="pl-s"><span class="pl-pds">&#39;</span>nodefy<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L173">173</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC173">    all<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L174">174</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC174">      expand<span class="pl-k">:</span> <span class="pl-c1">true</span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L175">175</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC175">      src<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>**/*.js<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L176">176</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC176">      cwd<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>src/<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L177">177</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC177">      dest<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>dist/common<span class="pl-pds">&#39;</span></span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L178">178</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC178">    }</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L179">179</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC179">  },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L180">180</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC180">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L181">181</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC181">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L182">182</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC182">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L183">183</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC183">  <span class="pl-c"><span class="pl-c">//</span> COPY AMD TO DIST</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L184">184</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC184">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L185">185</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC185">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L186">186</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC186">  <span class="pl-s"><span class="pl-pds">&#39;</span>copy<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L187">187</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC187">    amd<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L188">188</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC188">      expand<span class="pl-k">:</span> <span class="pl-c1">true</span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L189">189</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC189">      src<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>**/*.js<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L190">190</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC190">      cwd<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>src/<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L191">191</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC191">      dest<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>dist/amd<span class="pl-pds">&#39;</span></span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L192">192</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC192">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L193">193</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC193">    javascripts<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L194">194</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC194">      expand<span class="pl-k">:</span> <span class="pl-c1">true</span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L195">195</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC195">      src<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>*.js<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L196">196</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC196">      cwd<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>dist<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L197">197</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC197">      dest<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>docs/javascripts<span class="pl-pds">&#39;</span></span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L198">198</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC198">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L199">199</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC199">    readme<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L200">200</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC200">      src<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>README.md<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L201">201</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC201">      dest<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>docs/index.md<span class="pl-pds">&#39;</span></span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L202">202</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC202">    }</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L203">203</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC203">  },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L204">204</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC204">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L205">205</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC205">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L206">206</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC206">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L207">207</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC207">  <span class="pl-c"><span class="pl-c">//</span> WRAP</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L208">208</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC208">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L209">209</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC209">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L210">210</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC210">  <span class="pl-s"><span class="pl-pds">&#39;</span>wrap<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L211">211</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC211">    readme<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L212">212</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC212">      src<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>docs/index.md<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L213">213</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC213">      dest<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>docs/index.md<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L214">214</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC214">      options<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L215">215</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC215">        wrapper<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>---<span class="pl-cce">\n</span>layout: master<span class="pl-cce">\n</span>---<span class="pl-cce">\n</span>{% raw %}<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>{% endraw %}<span class="pl-pds">&#39;</span></span>]</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L216">216</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC216">      }</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L217">217</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC217">    }</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L218">218</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC218">  },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L219">219</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC219">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L220">220</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC220">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L221">221</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC221">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L222">222</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC222">  <span class="pl-c"><span class="pl-c">//</span> WATCH FILES</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L223">223</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC223">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L224">224</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC224">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L225">225</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC225">  <span class="pl-s"><span class="pl-pds">&#39;</span>watch<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L226">226</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC226">    options<span class="pl-k">:</span> { spawn<span class="pl-k">:</span> <span class="pl-c1">true</span> },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L227">227</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC227">    build<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L228">228</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC228">      files<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>Gruntfile.js<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L229">229</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC229">      tasks<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>build<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>docs<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L230">230</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC230">      options<span class="pl-k">:</span> { livereload<span class="pl-k">:</span> <span class="pl-c1">true</span> }</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L231">231</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC231">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L232">232</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC232">    src<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L233">233</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC233">      files<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>src/**/*.js<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L234">234</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC234">      tasks<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>build<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L235">235</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC235">      options<span class="pl-k">:</span> { livereload<span class="pl-k">:</span> <span class="pl-c1">true</span> }</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L236">236</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC236">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L237">237</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC237">    docs<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L238">238</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC238">      files<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>docs/**/*<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L239">239</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC239">      tasks<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>jekyll<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L240">240</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC240">      options<span class="pl-k">:</span> { livereload<span class="pl-k">:</span> <span class="pl-c1">true</span> }</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L241">241</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC241">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L242">242</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC242">    test<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L243">243</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC243">      files<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>test/**/*<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L244">244</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC244">      options<span class="pl-k">:</span> { livereload<span class="pl-k">:</span> <span class="pl-c1">true</span> }</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L245">245</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC245">    }</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L246">246</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC246">  },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L247">247</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC247">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L248">248</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC248">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L249">249</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC249">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L250">250</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC250">  <span class="pl-c"><span class="pl-c">//</span> STATIC SERVER</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L251">251</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC251">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L252">252</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC252">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L253">253</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC253">  <span class="pl-s"><span class="pl-pds">&#39;</span>connect<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L254">254</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC254">    docs<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L255">255</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC255">      options<span class="pl-k">:</span> { base<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>_site<span class="pl-pds">&#39;</span></span>, port<span class="pl-k">:</span> <span class="pl-c1">9998</span> }</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L256">256</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC256">    },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L257">257</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC257">    test<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L258">258</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC258">      options<span class="pl-k">:</span> { base<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span><span class="pl-pds">&#39;</span></span>, port<span class="pl-k">:</span> <span class="pl-c1">9999</span> }</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L259">259</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC259">    }</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L260">260</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC260">  },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L261">261</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC261">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L262">262</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC262">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L263">263</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC263">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L264">264</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC264">  <span class="pl-c"><span class="pl-c">//</span> BUILD AND SERVE JEKYLL DOCS</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L265">265</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC265">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L266">266</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC266">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L267">267</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC267">  <span class="pl-s"><span class="pl-pds">&#39;</span>jekyll<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L268">268</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC268">    all<span class="pl-k">:</span> {</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="10">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a title="v0.0.2" data-pjax="true" class="message f6 text-gray-dark" href="/jaridmargolin/formatter.js/commit/46b53256b614c877cb51cadade3ca4d8bb5e7022">v0.0.2</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="10"><time-ago datetime="2013-10-21T21:20:19Z">Oct 21, 2013</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L269">269</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC269">      options<span class="pl-k">:</span> {</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="10">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a title="Refactor to use AMD. Overhaul build process." data-pjax="true" class="message f6 text-gray-dark" href="/jaridmargolin/formatter.js/commit/f90acacb7c7d2c0bef27fc079699305b8f94431e">Refactor to use AMD. Overhaul build process.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="10"><time-ago datetime="2014-05-09T00:07:22Z">May 9, 2014</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/jaridmargolin/formatter.js/blame/4b94b66e1f4246df3875979dc6a460aa1e9d9d0e/Gruntfile.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L270">270</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC270">        src <span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>docs<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L271">271</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC271">        dest<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>_site<span class="pl-pds">&#39;</span></span></div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="10">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a title="v0.0.2" data-pjax="true" class="message f6 text-gray-dark" href="/jaridmargolin/formatter.js/commit/46b53256b614c877cb51cadade3ca4d8bb5e7022">v0.0.2</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="10"><time-ago datetime="2013-10-21T21:20:19Z">Oct 21, 2013</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L272">272</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC272">      }</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="10">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a title="Refactor to use AMD. Overhaul build process." data-pjax="true" class="message f6 text-gray-dark" href="/jaridmargolin/formatter.js/commit/f90acacb7c7d2c0bef27fc079699305b8f94431e">Refactor to use AMD. Overhaul build process.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="10"><time-ago datetime="2014-05-09T00:07:22Z">May 9, 2014</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/jaridmargolin/formatter.js/blame/4b94b66e1f4246df3875979dc6a460aa1e9d9d0e/Gruntfile.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L273">273</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC273">    }</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L274">274</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC274">  },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L275">275</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC275">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L276">276</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC276">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L277">277</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC277">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L278">278</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC278">  <span class="pl-c"><span class="pl-c">//</span> PUSH DOCS LIVE</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L279">279</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC279">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L280">280</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC280">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L281">281</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC281">  <span class="pl-s"><span class="pl-pds">&#39;</span>gh-pages<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L282">282</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC282">    options<span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L283">283</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC283">      base<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>docs<span class="pl-pds">&#39;</span></span></div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="10">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a title="v0.0.2" data-pjax="true" class="message f6 text-gray-dark" href="/jaridmargolin/formatter.js/commit/46b53256b614c877cb51cadade3ca4d8bb5e7022">v0.0.2</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="10"><time-ago datetime="2013-10-21T21:20:19Z">Oct 21, 2013</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L284">284</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC284">    },</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="10">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a title="Refactor to use AMD. Overhaul build process." data-pjax="true" class="message f6 text-gray-dark" href="/jaridmargolin/formatter.js/commit/f90acacb7c7d2c0bef27fc079699305b8f94431e">Refactor to use AMD. Overhaul build process.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="10"><time-ago datetime="2014-05-09T00:07:22Z">May 9, 2014</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/jaridmargolin/formatter.js/blame/4b94b66e1f4246df3875979dc6a460aa1e9d9d0e/Gruntfile.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L285">285</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC285">    src<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>**<span class="pl-pds">&#39;</span></span>]</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L286">286</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC286">  },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L287">287</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC287">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L288">288</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC288">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L289">289</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC289">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L290">290</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC290">  <span class="pl-c"><span class="pl-c">//</span> TESTS</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L291">291</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC291">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L292">292</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC292">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L293">293</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC293">  <span class="pl-s"><span class="pl-pds">&#39;</span>saucelabs-mocha<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L294">294</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC294">    all<span class="pl-k">:</span> {</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="10">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a title="v0.0.2" data-pjax="true" class="message f6 text-gray-dark" href="/jaridmargolin/formatter.js/commit/46b53256b614c877cb51cadade3ca4d8bb5e7022">v0.0.2</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="10"><time-ago datetime="2013-10-21T21:20:19Z">Oct 21, 2013</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L295">295</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC295">      options<span class="pl-k">:</span> {</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="10">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a title="Refactor to use AMD. Overhaul build process." data-pjax="true" class="message f6 text-gray-dark" href="/jaridmargolin/formatter.js/commit/f90acacb7c7d2c0bef27fc079699305b8f94431e">Refactor to use AMD. Overhaul build process.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="10"><time-ago datetime="2014-05-09T00:07:22Z">May 9, 2014</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/jaridmargolin/formatter.js/blame/4b94b66e1f4246df3875979dc6a460aa1e9d9d0e/Gruntfile.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L296">296</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC296">        urls<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>http://127.0.0.1:9999/test/_runner.html<span class="pl-pds">&#39;</span></span>],</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L297">297</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC297">        build<span class="pl-k">:</span> <span class="pl-c1">process</span>.<span class="pl-smi">env</span>.<span class="pl-c1">TRAVIS_JOB_ID</span> <span class="pl-k">||</span> <span class="pl-s"><span class="pl-pds">&#39;</span>&lt;%= pkg.version %&gt;<span class="pl-pds">&#39;</span></span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L298">298</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC298">        tunnelTimeout<span class="pl-k">:</span> <span class="pl-c1">5</span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L299">299</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC299">        concurrency<span class="pl-k">:</span> <span class="pl-c1">3</span>,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L300">300</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC300">        browsers<span class="pl-k">:</span> browsers,</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L301">301</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC301">        testname<span class="pl-k">:</span> <span class="pl-s"><span class="pl-pds">&#39;</span>formatter.js<span class="pl-pds">&#39;</span></span></div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="10">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a title="v0.0.2" data-pjax="true" class="message f6 text-gray-dark" href="/jaridmargolin/formatter.js/commit/46b53256b614c877cb51cadade3ca4d8bb5e7022">v0.0.2</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="10"><time-ago datetime="2013-10-21T21:20:19Z">Oct 21, 2013</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L302">302</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC302">      }</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L303">303</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC303">    }</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="10">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a title="Refactor to use AMD. Overhaul build process." data-pjax="true" class="message f6 text-gray-dark" href="/jaridmargolin/formatter.js/commit/f90acacb7c7d2c0bef27fc079699305b8f94431e">Refactor to use AMD. Overhaul build process.</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="10"><time-ago datetime="2014-05-09T00:07:22Z">May 9, 2014</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/jaridmargolin/formatter.js/blame/4b94b66e1f4246df3875979dc6a460aa1e9d9d0e/Gruntfile.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L304">304</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC304">  },</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L305">305</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC305">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L306">306</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC306">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L307">307</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC307">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L308">308</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC308">  <span class="pl-c"><span class="pl-c">//</span> MOCHA</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L309">309</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC309">  <span class="pl-c"><span class="pl-c">//</span> --------------------------------------------------------------------------</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L310">310</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC310">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L311">311</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC311">  <span class="pl-s"><span class="pl-pds">&#39;</span>mocha_phantomjs<span class="pl-pds">&#39;</span></span><span class="pl-k">:</span> {</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L312">312</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC312">    all<span class="pl-k">:</span> [<span class="pl-s"><span class="pl-pds">&#39;</span>test/_runner.html<span class="pl-pds">&#39;</span></span>]</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L313">313</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC313">  }</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L314">314</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC314">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L315">315</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC315">});</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L316">316</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC316">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L317">317</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC317">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L318">318</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC318"><span class="pl-c"><span class="pl-c">//</span> Tasks</span></div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L319">319</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC319"><span class="pl-smi">grunt</span>.<span class="pl-en">registerTask</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>default<span class="pl-pds">&#39;</span></span>, [<span class="pl-s"><span class="pl-pds">&#39;</span>build<span class="pl-pds">&#39;</span></span>]);</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L320">320</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC320"><span class="pl-smi">grunt</span>.<span class="pl-en">registerTask</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>dev<span class="pl-pds">&#39;</span></span>, [<span class="pl-s"><span class="pl-pds">&#39;</span>build<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>docs<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>connect<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>watch<span class="pl-pds">&#39;</span></span>]);</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L321">321</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC321"><span class="pl-smi">grunt</span>.<span class="pl-en">registerTask</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>test<span class="pl-pds">&#39;</span></span>, [<span class="pl-s"><span class="pl-pds">&#39;</span>build<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>mocha_phantomjs<span class="pl-pds">&#39;</span></span>]);</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L322">322</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC322"><span class="pl-smi">grunt</span>.<span class="pl-en">registerTask</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>test-cloud<span class="pl-pds">&#39;</span></span>, [<span class="pl-s"><span class="pl-pds">&#39;</span>build<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>connect:test<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>saucelabs-mocha<span class="pl-pds">&#39;</span></span>]);</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L323">323</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC323"><span class="pl-smi">grunt</span>.<span class="pl-en">registerTask</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>docs<span class="pl-pds">&#39;</span></span>, [<span class="pl-s"><span class="pl-pds">&#39;</span>clean:docs<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>copy:javascripts<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>copy:readme<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>wrap:readme<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>jekyll<span class="pl-pds">&#39;</span></span>]);</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L324">324</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC324"><span class="pl-smi">grunt</span>.<span class="pl-en">registerTask</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>build<span class="pl-pds">&#39;</span></span>, [<span class="pl-s"><span class="pl-pds">&#39;</span>jshint:src<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>clean:dist<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>requirejs<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>umd:jquery<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>umd:umd<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>concat:umd<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>concat:jquery<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>uglify:umd<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>uglify:jquery<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>nodefy<span class="pl-pds">&#39;</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>copy:amd<span class="pl-pds">&#39;</span></span>]);</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="10">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a title="v0.0.2" data-pjax="true" class="message f6 text-gray-dark" href="/jaridmargolin/formatter.js/commit/46b53256b614c877cb51cadade3ca4d8bb5e7022">v0.0.2</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="10"><time-ago datetime="2013-10-21T21:20:19Z">Oct 21, 2013</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L325">325</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC325">
</div>
                </div>
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L326">326</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC326">
</div>
                </div>
            </div>
          </div>

          <div class="blame-hunk d-flex border-gray-light border-bottom">

            <div class="blame-commit flex-self-stretch mr-1" data-heat="10">
              <div class="blame-commit-info pl-1 pr-2">

                <div class="no-wrap d-flex flex-items-start">
                  
<div class="AvatarStack flex-self-start ">
  <div class="AvatarStack-body" aria-label="jaridmargolin">

        <a class="avatar" data-skip-pjax="true" data-hovercard-user-id="933685" href="/jaridmargolin">
          <img height="20" width="20" alt="@jaridmargolin" src="https://avatars3.githubusercontent.com/u/933685?s=60&amp;v=4" />
</a>  </div>
</div>

                  <div class="blame-commit-content d-flex no-wrap flex-items-center">
                    <div class="blame-commit-message overflow-hidden pt-1 f6">
                        <a title="Merge fixes from number #32 &amp; #33" data-pjax="true" class="message f6 text-gray-dark" href="/jaridmargolin/formatter.js/commit/470d7bb7ccd369a96ff0e9938292094ffe545010">Merge fixes from number <a href="https://github.com/firstopinion/formatter.js/pull/32" class="issue-link js-issue-link" data-error-text="Failed to load issue title" data-id="26407408" data-permission-text="Issue title is private" data-url="https://github.com/firstopinion/formatter.js/issues/32">#32</a> &amp; <a href="https://github.com/firstopinion/formatter.js/pull/33" class="issue-link js-issue-link" data-error-text="Failed to load issue title" data-id="26409646" data-permission-text="Issue title is private" data-url="https://github.com/firstopinion/formatter.js/issues/33">#33</a>
</a>
                    </div>
                  </div>
                  <div class="blame-commit-date ml-3" data-heat="10"><time-ago datetime="2014-02-28T00:46:29Z">Feb 28, 2014</time-ago></div>
                </div>
              </div>
            </div>

            <div class="blob-reblame pl-1 pr-1">
                <a href="/jaridmargolin/formatter.js/blame/29833fabf868404906cbd42c13f7ea757dd12de6/Gruntfile.js"
                  aria-label="View blame prior to this change" class="reblame-link link-hover-blue no-underline tooltipped tooltipped-e d-inline-block pr-1">
                  <svg class="octicon octicon-versions" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                </a>
            </div>

            <div class="width-full">
                <div class="d-flex flex-justify-start flex-items-start">
                  <div class="blob-num blame-blob-num bg-gray-light js-line-number" id="L327">327</div>
                  <div class="blob-code blob-code-inner js-file-line" id="LC327">};</div>
                </div>
            </div>
          </div>
      </div>
    </div>

  </div>


  </div>
  <div class="modal-backdrop js-touch-events"></div>
</div>

    </div>
  </div>

  </div>

      
<div class="footer container-lg px-3" role="contentinfo">
  <div class="position-relative d-flex flex-justify-between pt-6 pb-2 mt-6 f6 text-gray border-top border-gray-light ">
    <ul class="list-style-none d-flex flex-wrap ">
      <li class="mr-3">&copy; 2018 <span title="0.13389s from unicorn-4049284824-s76b9">GitHub</span>, Inc.</li>
        <li class="mr-3"><a data-ga-click="Footer, go to terms, text:terms" href="https://github.com/site/terms">Terms</a></li>
        <li class="mr-3"><a data-ga-click="Footer, go to privacy, text:privacy" href="https://github.com/site/privacy">Privacy</a></li>
        <li class="mr-3"><a href="https://help.github.com/articles/github-security/" data-ga-click="Footer, go to security, text:security">Security</a></li>
        <li class="mr-3"><a href="https://status.github.com/" data-ga-click="Footer, go to status, text:status">Status</a></li>
        <li><a data-ga-click="Footer, go to help, text:help" href="https://help.github.com">Help</a></li>
    </ul>

    <a aria-label="Homepage" title="GitHub" class="footer-octicon" href="https://github.com">
      <svg height="24" class="octicon octicon-mark-github" viewBox="0 0 16 16" version="1.1" width="24" aria-hidden="true"><path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0 0 16 8c0-4.42-3.58-8-8-8z"/></svg>
</a>
   <ul class="list-style-none d-flex flex-wrap ">
        <li class="mr-3"><a data-ga-click="Footer, go to contact, text:contact" href="https://github.com/contact">Contact GitHub</a></li>
      <li class="mr-3"><a href="https://developer.github.com" data-ga-click="Footer, go to api, text:api">API</a></li>
      <li class="mr-3"><a href="https://training.github.com" data-ga-click="Footer, go to training, text:training">Training</a></li>
      <li class="mr-3"><a href="https://shop.github.com" data-ga-click="Footer, go to shop, text:shop">Shop</a></li>
        <li class="mr-3"><a data-ga-click="Footer, go to blog, text:blog" href="https://github.com/blog">Blog</a></li>
        <li><a data-ga-click="Footer, go to about, text:about" href="https://github.com/about">About</a></li>

    </ul>
  </div>
  <div class="d-flex flex-justify-center pb-6">
    <span class="f6 text-gray-light"></span>
  </div>
</div>



  <div id="ajax-error-message" class="ajax-error-message flash flash-error">
    <svg class="octicon octicon-alert" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M8.865 1.52c-.18-.31-.51-.5-.87-.5s-.69.19-.87.5L.275 13.5c-.18.31-.18.69 0 1 .19.31.52.5.87.5h13.7c.36 0 .69-.19.86-.5.17-.31.18-.69.01-1L8.865 1.52zM8.995 13h-2v-2h2v2zm0-3h-2V6h2v4z"/></svg>
    <button type="button" class="flash-close js-ajax-error-dismiss" aria-label="Dismiss error">
      <svg class="octicon octicon-x" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48z"/></svg>
    </button>
    You can't perform that action at this time.
  </div>


    <script crossorigin="anonymous" type="application/javascript" src="https://assets-cdn.github.com/assets/compat-680e7bbbbe79068a1cb3142329468a6f.js"></script>
    <script crossorigin="anonymous" type="application/javascript" src="https://assets-cdn.github.com/assets/frameworks-4a55ab3fcf005abef1e8b859483f3cce.js"></script>
    
    <script crossorigin="anonymous" async="async" type="application/javascript" src="https://assets-cdn.github.com/assets/github-2d728fdd9eab7e0c5ed0f7ee90304a01.js"></script>
    
    
    
    
  <div class="js-stale-session-flash stale-session-flash flash flash-warn flash-banner d-none">
    <svg class="octicon octicon-alert" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M8.865 1.52c-.18-.31-.51-.5-.87-.5s-.69.19-.87.5L.275 13.5c-.18.31-.18.69 0 1 .19.31.52.5.87.5h13.7c.36 0 .69-.19.86-.5.17-.31.18-.69.01-1L8.865 1.52zM8.995 13h-2v-2h2v2zm0-3h-2V6h2v4z"/></svg>
    <span class="signed-in-tab-flash">You signed in with another tab or window. <a href="">Reload</a> to refresh your session.</span>
    <span class="signed-out-tab-flash">You signed out in another tab or window. <a href="">Reload</a> to refresh your session.</span>
  </div>
  <div class="facebox" id="facebox" style="display:none;">
  <div class="facebox-popup">
    <div class="facebox-content" role="dialog" aria-labelledby="facebox-header" aria-describedby="facebox-description">
    </div>
    <button type="button" class="facebox-close js-facebox-close" aria-label="Close modal">
      <svg class="octicon octicon-x" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48z"/></svg>
    </button>
  </div>
</div>

  <div class="Popover js-hovercard-content position-absolute" style="display: none; outline: none;" tabindex="0">
  <div class="Popover-message Popover-message--bottom-left Popover-message--large Box box-shadow-large" style="width:360px;">
  </div>
</div>

<div id="hovercard-aria-description" class="sr-only">
  Press h to open a hovercard with more details.
</div>


  </body>
</html>

