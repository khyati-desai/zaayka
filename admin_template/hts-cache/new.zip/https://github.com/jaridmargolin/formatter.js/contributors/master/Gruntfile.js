

  <div class="commit-tease">
      <span class="float-right">
        <a class="commit-tease-sha" href="/jaridmargolin/formatter.js/commit/f90acacb7c7d2c0bef27fc079699305b8f94431e" data-pjax>
          f90acac
        </a>
        <relative-time datetime="2014-05-09T00:07:22Z">May 9, 2014</relative-time>
      </span>
      <div>
        <a rel="author" data-skip-pjax="true" href="/jaridmargolin"><img class="avatar" src="https://avatars0.githubusercontent.com/u/933685?s=40&amp;v=4" width="20" height="20" alt="@jaridmargolin" data-hovercard-user-id="933685" /></a>
        <a class="user-mention" rel="author" data-hovercard-user-id="933685" href="/jaridmargolin">jaridmargolin</a>
          <a data-pjax="true" title="Refactor to use AMD. Overhaul build process." class="message" href="/jaridmargolin/formatter.js/commit/f90acacb7c7d2c0bef27fc079699305b8f94431e">Refactor to use AMD. Overhaul build process.</a>
      </div>

    <div class="commit-tease-contributors">
      <button type="button" class="btn-link muted-link contributors-toggle" data-facebox="#blob_contributors_box">
        <strong>3</strong>
         contributors
      </button>
          <a class="avatar-link" aria-label="jaridmargolin" href="/jaridmargolin/formatter.js/commits/master/Gruntfile.js?author=jaridmargolin"><img class="avatar" src="https://avatars0.githubusercontent.com/u/933685?s=40&amp;v=4" width="20" height="20" alt="@jaridmargolin" data-hovercard-user-id="933685" /> </a>
    <a class="avatar-link" aria-label="brianpeiris" href="/jaridmargolin/formatter.js/commits/master/Gruntfile.js?author=brianpeiris"><img class="avatar" src="https://avatars0.githubusercontent.com/u/79419?s=40&amp;v=4" width="20" height="20" alt="@brianpeiris" data-hovercard-user-id="79419" /> </a>
    <a class="avatar-link" aria-label="mickeyreiss" href="/jaridmargolin/formatter.js/commits/master/Gruntfile.js?author=mickeyreiss"><img class="avatar" src="https://avatars1.githubusercontent.com/u/47405?s=40&amp;v=4" width="20" height="20" alt="@mickeyreiss" data-hovercard-user-id="47405" /> </a>


    </div>

    <div id="blob_contributors_box" style="display:none">
      <h2 class="facebox-header" data-facebox-id="facebox-header">Users who have contributed to this file</h2>
      <ul class="facebox-user-list" data-facebox-id="facebox-description">
          <li class="facebox-user-list-item">
            <img src="https://avatars1.githubusercontent.com/u/933685?s=48&amp;v=4" width="24" height="24" alt="@jaridmargolin" data-hovercard-user-id="933685" />
            <a data-hovercard-user-id="933685" href="/jaridmargolin">jaridmargolin</a>
          </li>
          <li class="facebox-user-list-item">
            <img src="https://avatars1.githubusercontent.com/u/79419?s=48&amp;v=4" width="24" height="24" alt="@brianpeiris" data-hovercard-user-id="79419" />
            <a data-hovercard-user-id="79419" href="/brianpeiris">brianpeiris</a>
          </li>
          <li class="facebox-user-list-item">
            <img src="https://avatars0.githubusercontent.com/u/47405?s=48&amp;v=4" width="24" height="24" alt="@mickeyreiss" data-hovercard-user-id="47405" />
            <a data-hovercard-user-id="47405" href="/mickeyreiss">mickeyreiss</a>
          </li>
      </ul>
    </div>
  </div>
